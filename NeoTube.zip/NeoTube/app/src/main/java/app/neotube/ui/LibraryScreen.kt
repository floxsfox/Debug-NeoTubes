package app.neotube.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.WatchLater
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.exoplayer.offline.Download as Dl
import app.neotube.data.Library
import app.neotube.data.Local
import app.neotube.data.Playback
import app.neotube.data.ServiceLocator

object LibState {
    var tab by mutableIntStateOf(0)
    val listState = LazyListState()
}

private val Tabs = listOf("Riwayat", "Tonton nanti", "Disukai", "Playlist", "Unduhan")

@Composable
fun LibraryScreen() {
    val ctx = LocalContext.current
    val history by Local.history.items.collectAsStateWithLifecycle()
    val later by Local.watchLater.items.collectAsStateWithLifecycle()
    val liked by Local.liked.items.collectAsStateWithLifecycle()
    val lists by Local.playlists.items.collectAsStateWithLifecycle()
    val entries by Library.entries.collectAsStateWithLifecycle()
    val dls by ServiceLocator.downloads.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        state = LibState.listState,
        contentPadding = PaddingValues(top = topPad(), bottom = bottomPad()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader("Pustaka") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
                items(Tabs.size) { i -> GlassChip(Tabs[i], LibState.tab == i, { LibState.tab = i }) }
            }
        }

        when (LibState.tab) {
            0 -> {
                if (history.isEmpty()) {
                    item { EmptyState(Icons.Rounded.History, "Riwayat kosong", "Video yang kamu tonton muncul di sini, lengkap dengan posisi terakhir.") }
                } else {
                    item {
                        Row(Modifier.padding(horizontal = 16.dp)) {
                            GlassChip("Hapus semua riwayat", false, { Local.history.clear(); UiState.toast("Riwayat dihapus") }, icon = Icons.Rounded.Delete)
                        }
                    }
                    items(history) { h ->
                        val p = if (h.durMs > 0) h.posMs.toFloat() / h.durMs else null
                        VideoRow(
                            h.item, { Playback.open(h.item.url) }, Modifier.padding(horizontal = 16.dp), p,
                            trailing = { SmallIcon(Icons.Rounded.Close) { Local.history.remove(h.item.url) } },
                        )
                    }
                }
            }
            1 -> {
                if (later.isEmpty()) {
                    item { EmptyState(Icons.Rounded.WatchLater, "Belum ada video", "Simpan video dari menu ⋮ untuk ditonton nanti.") }
                } else {
                    item { PlayAll { Playback.playList(later) } }
                    items(later) { v ->
                        VideoRow(v, { Playback.open(v.url) }, Modifier.padding(horizontal = 16.dp),
                            trailing = { SmallIcon(Icons.Rounded.Delete) { Local.watchLater.remove(v.url) } })
                    }
                }
            }
            2 -> {
                if (liked.isEmpty()) {
                    item { EmptyState(Icons.Rounded.Favorite, "Belum ada yang disukai", "Ketuk Suka di halaman video atau menu ⋮.") }
                } else {
                    item { PlayAll { Playback.playList(liked) } }
                    items(liked) { v ->
                        VideoRow(v, { Playback.open(v.url) }, Modifier.padding(horizontal = 16.dp),
                            trailing = { SmallIcon(Icons.Rounded.Delete) { Local.liked.remove(v.url) } })
                    }
                }
            }
            3 -> {
                item {
                    Row(Modifier.padding(horizontal = 16.dp)) {
                        GlassChip("Playlist baru", false, { UiState.newPlaylistFirst = null; UiState.newPlaylistOpen = true }, icon = Icons.Rounded.PlaylistAdd)
                    }
                }
                if (lists.isEmpty()) {
                    item { EmptyState(Icons.Rounded.PlaylistPlay, "Belum ada playlist", "Buat playlist sendiri dan isi dari menu ⋮ tiap video.") }
                }
                items(lists) { p ->
                    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp), onClick = { Nav.push(Screen.UserPlaylist(p.id)) }) {
                        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Thumb(p.items.firstOrNull()?.thumb, 0, Modifier.width(120.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(p.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${p.items.size} video", color = TextDim, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
            else -> {
                item {
                    Text(
                        "Terpakai ${fmtBytes(ServiceLocator.cache.cacheSpace)} di perangkat",
                        Modifier.padding(horizontal = 20.dp), color = TextDim, fontSize = 13.sp,
                    )
                }
                if (entries.isEmpty()) {
                    item { EmptyState(Icons.Rounded.Download, "Belum ada unduhan", "Buka video, pilih kualitas, lalu ketuk Unduh. Bisa diputar tanpa internet.") }
                }
                items(entries) { e ->
                    val parts = listOfNotNull(dls[e.vKey], e.aKey?.let { dls[it] })
                    val expected = if (e.aKey != null) 2 else 1
                    val done = parts.size == expected && parts.all { it.state == Dl.STATE_COMPLETED }
                    val failed = parts.any { it.state == Dl.STATE_FAILED }
                    val pct: Float = if (parts.isEmpty()) 0f else parts.map { it.percentDownloaded.coerceAtLeast(0f) }.average().toFloat()
                    val bytes = parts.sumOf { it.bytesDownloaded }
                    GlassCard(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp),
                        onClick = if (done) ({ Playback.openOffline(e) }) else null,
                    ) {
                        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Thumb(e.thumb, e.duration, Modifier.width(130.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(e.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                val status = when {
                                    done -> "${e.label} • ${fmtBytes(bytes)} • siap offline"
                                    failed -> "Gagal — hapus lalu unduh ulang"
                                    parts.isEmpty() -> "Menunggu antrean"
                                    else -> "Mengunduh ${pct.toInt()}% • ${fmtBytes(bytes)}"
                                }
                                Text(status, color = if (failed) Rose else TextDim, fontSize = 12.sp, maxLines = 2)
                                if (!done && !failed) {
                                    LinearProgressIndicator(
                                        progress = { (pct / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth(),
                                        color = Cyan, trackColor = Color.White.copy(alpha = 0.15f),
                                    )
                                }
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (done) GlassIconButton(Icons.Rounded.PlayArrow, { Playback.openOffline(e) }, size = 40.dp, fill = AccentFill)
                                GlassIconButton(Icons.Rounded.Delete, { Library.remove(ctx, e) }, size = 40.dp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayAll(onClick: () -> Unit) {
    Row(Modifier.padding(horizontal = 16.dp)) {
        GlassChip("Putar semua", true, onClick, icon = Icons.Rounded.PlayArrow)
    }
}

@Composable
fun SmallIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Icon(
        icon, null, tint = Color.White.copy(alpha = 0.8f),
        modifier = Modifier.clip(CircleShape).clickable(onClick = onClick).padding(6.dp),
    )
}
