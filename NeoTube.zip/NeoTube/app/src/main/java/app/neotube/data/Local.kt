package app.neotube.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

private fun prefs() = ServiceLocator.app.getSharedPreferences("neotube_local", Context.MODE_PRIVATE)

private fun readArray(key: String): JSONArray =
    try { JSONArray(prefs().getString(key, "[]")) } catch (e: Exception) { JSONArray() }

fun VideoItem.toJson(): JSONObject = JSONObject()
    .put("url", url).put("title", title).put("uploader", uploader).put("thumb", thumb ?: "")
    .put("duration", duration).put("views", views).put("uploaded", uploaded ?: "")

fun JSONObject.toVideoItem() = VideoItem(
    url = getString("url"),
    title = optString("title", ""),
    uploader = optString("uploader", ""),
    thumb = optString("thumb", "").ifBlank { null },
    duration = optLong("duration", 0),
    views = optLong("views", -1),
    uploaded = optString("uploaded", "").ifBlank { null },
)

/** Daftar video lokal (Tonton nanti, Disukai). Terbaru di atas. */
class VideoList(private val key: String, private val max: Int = 300) {
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<VideoItem>> = _items

    private fun load(): List<VideoItem> {
        val a = readArray(key)
        return (0 until a.length()).mapNotNull {
            try { a.getJSONObject(it).toVideoItem() } catch (e: Exception) { null }
        }
    }

    private fun save() {
        val a = JSONArray()
        _items.value.forEach { a.put(it.toJson()) }
        prefs().edit().putString(key, a.toString()).apply()
    }

    fun has(url: String) = _items.value.any { it.url == url }

    fun add(v: VideoItem) {
        _items.value = (listOf(v) + _items.value.filter { it.url != v.url }).take(max)
        save()
    }

    fun remove(url: String) {
        _items.value = _items.value.filter { it.url != url }
        save()
    }

    /** true = sekarang tersimpan, false = baru dihapus. */
    fun toggle(v: VideoItem): Boolean = if (has(v.url)) { remove(v.url); false } else { add(v); true }

    fun clear() {
        _items.value = emptyList()
        save()
    }
}

data class HistEntry(val item: VideoItem, val posMs: Long, val durMs: Long, val at: Long)

class HistoryStore {
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<HistEntry>> = _items

    private fun load(): List<HistEntry> {
        val a = readArray("history")
        return (0 until a.length()).mapNotNull {
            try {
                val o = a.getJSONObject(it)
                HistEntry(o.toVideoItem(), o.optLong("pos", 0), o.optLong("dur", 0), o.optLong("at", 0))
            } catch (e: Exception) { null }
        }
    }

    private fun save() {
        val a = JSONArray()
        _items.value.forEach { a.put(it.item.toJson().put("pos", it.posMs).put("dur", it.durMs).put("at", it.at)) }
        prefs().edit().putString("history", a.toString()).apply()
    }

    fun update(v: VideoItem, pos: Long, dur: Long) {
        _items.value = (listOf(HistEntry(v, pos, dur, System.currentTimeMillis())) +
            _items.value.filter { it.item.url != v.url }).take(300)
        save()
    }

    fun positionOf(url: String): Long = _items.value.firstOrNull { it.item.url == url }?.posMs ?: 0L

    fun remove(url: String) {
        _items.value = _items.value.filter { it.item.url != url }
        save()
    }

    fun clear() {
        _items.value = emptyList()
        save()
    }
}

data class UserPlaylist(val id: String, val name: String, val items: List<VideoItem>)

class PlaylistStore {
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<UserPlaylist>> = _items

    private fun load(): List<UserPlaylist> {
        val a = readArray("playlists")
        return (0 until a.length()).mapNotNull {
            try {
                val o = a.getJSONObject(it)
                val arr = o.getJSONArray("items")
                UserPlaylist(
                    o.getString("id"), o.getString("name"),
                    (0 until arr.length()).map { i -> arr.getJSONObject(i).toVideoItem() },
                )
            } catch (e: Exception) { null }
        }
    }

    private fun save() {
        val a = JSONArray()
        _items.value.forEach { p ->
            val arr = JSONArray()
            p.items.forEach { arr.put(it.toJson()) }
            a.put(JSONObject().put("id", p.id).put("name", p.name).put("items", arr))
        }
        prefs().edit().putString("playlists", a.toString()).apply()
    }

    fun create(name: String, first: VideoItem? = null): String {
        val id = UUID.randomUUID().toString()
        _items.value = listOf(UserPlaylist(id, name.trim(), listOfNotNull(first))) + _items.value
        save()
        return id
    }

    fun delete(id: String) {
        _items.value = _items.value.filter { it.id != id }
        save()
    }

    fun add(id: String, v: VideoItem) {
        _items.value = _items.value.map { p ->
            if (p.id == id && p.items.none { it.url == v.url }) p.copy(items = p.items + v) else p
        }
        save()
    }

    fun remove(id: String, url: String) {
        _items.value = _items.value.map { p -> if (p.id == id) p.copy(items = p.items.filter { it.url != url }) else p }
        save()
    }
}

data class Sub(val url: String, val name: String, val avatar: String?)

class SubStore {
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<Sub>> = _items

    private fun load(): List<Sub> {
        val a = readArray("subs")
        return (0 until a.length()).mapNotNull {
            try {
                val o = a.getJSONObject(it)
                Sub(o.getString("url"), o.optString("name", ""), o.optString("avatar", "").ifBlank { null })
            } catch (e: Exception) { null }
        }
    }

    private fun save() {
        val a = JSONArray()
        _items.value.forEach { a.put(JSONObject().put("url", it.url).put("name", it.name).put("avatar", it.avatar ?: "")) }
        prefs().edit().putString("subs", a.toString()).apply()
    }

    fun has(url: String) = _items.value.any { it.url == url }

    fun toggle(s: Sub): Boolean {
        val now = !has(s.url)
        _items.value = if (now) listOf(s) + _items.value else _items.value.filter { it.url != s.url }
        save()
        return now
    }
}

class StringList(private val key: String, private val max: Int) {
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<String>> = _items

    private fun load(): List<String> {
        val a = readArray(key)
        return (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    }

    private fun save() {
        val a = JSONArray()
        _items.value.forEach { a.put(it) }
        prefs().edit().putString(key, a.toString()).apply()
    }

    fun push(s: String) {
        _items.value = (listOf(s) + _items.value.filter { !it.equals(s, ignoreCase = true) }).take(max)
        save()
    }

    fun remove(s: String) {
        _items.value = _items.value.filter { it != s }
        save()
    }

    fun clear() {
        _items.value = emptyList()
        save()
    }
}

object Local {
    val history by lazy { HistoryStore() }
    val watchLater by lazy { VideoList("watch_later") }
    val liked by lazy { VideoList("liked") }
    val playlists by lazy { PlaylistStore() }
    val subs by lazy { SubStore() }
    val searches by lazy { StringList("searches", 15) }
}

object Settings {
    /** 0 = otomatis (maks 1080p). */
    var defaultHeight by mutableIntStateOf(0)
        private set
    var dataSaver by mutableStateOf(true)
        private set
    var autoplay by mutableStateOf(true)
        private set
    var resume by mutableStateOf(true)
        private set

    private fun sp() = ServiceLocator.app.getSharedPreferences("neotube_settings", Context.MODE_PRIVATE)

    fun load() {
        val p = sp()
        defaultHeight = p.getInt("h", 0)
        dataSaver = p.getBoolean("saver", true)
        autoplay = p.getBoolean("auto", true)
        resume = p.getBoolean("resume", true)
    }

    fun saveHeight(v: Int) { defaultHeight = v; sp().edit().putInt("h", v).apply() }
    fun saveDataSaver(v: Boolean) { dataSaver = v; sp().edit().putBoolean("saver", v).apply() }
    fun saveAutoplay(v: Boolean) { autoplay = v; sp().edit().putBoolean("auto", v).apply() }
    fun saveResume(v: Boolean) { resume = v; sp().edit().putBoolean("resume", v).apply() }
}
