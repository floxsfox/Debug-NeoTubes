package app.neotube

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import app.neotube.data.Playback
import app.neotube.data.Repo
import app.neotube.ui.NeoTheme
import app.neotube.ui.NeoTubeApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        if (savedInstanceState == null) handleIntent(intent)
        setContent { NeoTheme { NeoTubeApp() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Tautan YouTube dari aplikasi lain (buka / bagikan) langsung diputar. */
    private fun handleIntent(i: Intent?) {
        val raw = i?.dataString ?: i?.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val link = Regex("https?://\\S+").find(raw)?.value ?: return
        if (Repo.isVideoUrl(link)) Playback.open(link)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Playback.active && Playback.expanded && Playback.isPlaying && !Playback.audioOnly) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            } catch (e: Exception) {
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        Playback.inPip = isInPictureInPictureMode
    }
}
