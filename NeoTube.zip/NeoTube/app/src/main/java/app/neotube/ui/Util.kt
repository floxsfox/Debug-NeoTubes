package app.neotube.ui

import java.util.Locale

fun fmtDur(sec: Long): String {
    val s = sec.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val x = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, x) else String.format(Locale.US, "%d:%02d", m, x)
}

fun fmtCount(n: Long): String = when {
    n < 0 -> ""
    n >= 1_000_000_000 -> String.format(Locale.US, "%.1f M", n / 1e9)
    n >= 1_000_000 -> String.format(Locale.US, "%.1f jt", n / 1e6)
    n >= 1_000 -> String.format(Locale.US, "%.1f rb", n / 1e3)
    else -> n.toString()
}.replace(".0 ", " ")

fun fmtBytes(b: Long): String = when {
    b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= 1L shl 20 -> String.format(Locale.US, "%.0f MB", b / 1048576.0)
    b >= 1L shl 10 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}
