package app.neotube.data

import android.content.ComponentName
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.SingleSampleMediaSource
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Satu pemutar untuk seluruh aplikasi: tetap jalan saat diperkecil (mini player) atau di latar belakang. */
object Playback {
    val exo: ExoPlayer by lazy {
        ExoPlayer.Builder(ServiceLocator.app, DefaultMediaSourceFactory(ServiceLocator.playbackFactory))
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true,
            )
            .build()
    }

    var info by mutableStateOf<PlayInfo?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var selected by mutableStateOf<StreamChoice?>(null)
        private set
    var subIndex by mutableStateOf(-1)
        private set
    var speed by mutableFloatStateOf(1f)
        private set
    var audioOnly by mutableStateOf(false)
        private set
    var loop by mutableStateOf(false)
        private set
    /** 0 = mati, -1 = di akhir video, >0 = waktu henti (ms epoch). */
    var sleepAt by mutableLongStateOf(0L)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var bufferedMs by mutableLongStateOf(0L)
        private set
    var active by mutableStateOf(false)
        private set
    var offline by mutableStateOf(false)
        private set

    var expanded by mutableStateOf(false)
    var inPip by mutableStateOf(false)

    val queue = mutableStateListOf<VideoItem>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loadJob: Job? = null
    private var sleepJob: Job? = null
    private var recoverAt = 0L
    private var inited = false
    private var controller: Any? = null
    private var lastUrl: String? = null

    fun init() {
        if (inited) return
        inited = true
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (!playing) saveProgress()
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED) onEnded()
            }

            override fun onPlayerError(e: PlaybackException) = handleError(e)
        })
        scope.launch {
            while (true) {
                delay(300)
                tick()
            }
        }
        scope.launch {
            while (true) {
                delay(5000)
                if (exo.isPlaying) saveProgress()
            }
        }
        // Mengikat service sesi media -> notifikasi kontrol + jalan terus di latar belakang.
        val app = ServiceLocator.app
        controller = MediaController.Builder(app, SessionToken(app, ComponentName(app, PlaybackService::class.java)))
            .buildAsync()
    }

    private fun tick() {
        if (!active || exo.mediaItemCount == 0) return
        positionMs = exo.currentPosition
        bufferedMs = exo.bufferedPosition
        val d = exo.duration
        durationMs = if (d == C.TIME_UNSET || d <= 0) (info?.duration ?: 0L) * 1000 else d
    }

    // ---------- membuka video ----------

    fun open(url: String) {
        lastUrl = url
        saveProgress()
        loadJob?.cancel()
        exo.stop()
        exo.clearMediaItems()
        offline = false
        active = true
        expanded = true
        info = null
        selected = null
        subIndex = -1
        error = null
        loading = true
        positionMs = 0
        durationMs = 0
        loadJob = scope.launch {
            try {
                val i = Repo.load(url)
                info = i
                selected = pick(i)
                loading = false
                var resumeAt = 0L
                if (Settings.resume) {
                    val p = Local.history.positionOf(i.url)
                    if (p > 15_000 && p < i.duration * 1000 - 15_000) resumeAt = p
                }
                Local.history.update(i.toItem(), resumeAt, i.duration * 1000)
                applyMedia(resumeAt)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                loading = false
                error = e.message ?: e.toString()
            }
        }
    }

    fun openOffline(e: LibEntry) {
        saveProgress()
        loadJob?.cancel()
        exo.stop()
        offline = true
        active = true
        expanded = true
        loading = false
        error = null
        audioOnly = false
        val i = Repo.offlineInfo(e)
        info = i
        selected = i.qualities.first()
        subIndex = -1
        applyMedia(0L)
    }

    /** Coba lagi: kalau info belum termuat -> muat ulang; kalau sudah -> muat ulang URL stream di posisi sama. */
    fun retry() {
        if (offline) return
        if (info == null) {
            lastUrl?.let { open(it) }
        } else {
            error = null
            reload(exo.currentPosition)
        }
    }

    private fun pick(i: PlayInfo): StreamChoice? {
        val cap = when {
            Settings.dataSaver && onMobile() -> 480
            Settings.defaultHeight > 0 -> Settings.defaultHeight
            else -> 1080
        }
        return i.qualities.firstOrNull { it.height <= cap } ?: i.qualities.lastOrNull()
    }

    private fun onMobile(): Boolean = try {
        val cm = ServiceLocator.app.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    } catch (e: Exception) {
        false
    }

    // ---------- sumber media ----------

    private fun meta(i: PlayInfo): MediaMetadata = MediaMetadata.Builder()
        .setTitle(i.title)
        .setArtist(i.uploader)
        .setArtworkUri(i.thumb?.let { Uri.parse(it) })
        .build()

    private fun prog(i: PlayInfo, url: String, key: String): MediaSource =
        ProgressiveMediaSource.Factory(ServiceLocator.playbackFactory).createMediaSource(
            MediaItem.Builder().setUri(url).setCustomCacheKey(key).setMediaMetadata(meta(i)).build(),
        )

    private fun applyMedia(startPos: Long? = null) {
        val i = info ?: return
        val pos = startPos ?: if (exo.mediaItemCount > 0) exo.currentPosition else 0L
        error = null
        val q = selected
        val hls = i.hlsUrl
        val au = i.audioUrl
        val ak = i.audioKey
        when {
            audioOnly && au != null && ak != null -> exo.setMediaSource(prog(i, au, ak), pos)
            q != null -> {
                val list = ArrayList<MediaSource>()
                list.add(prog(i, q.url, q.key))
                if (au != null && ak != null) list.add(prog(i, au, ak))
                if (subIndex in i.subs.indices) {
                    val s = i.subs[subIndex]
                    val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.parse(s.url))
                        .setMimeType(s.mime)
                        .setLanguage(s.lang)
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                    list.add(SingleSampleMediaSource.Factory(ServiceLocator.httpFactory).createMediaSource(cfg, C.TIME_UNSET))
                }
                exo.setMediaSource(if (list.size == 1) list[0] else MergingMediaSource(*list.toTypedArray()), pos)
            }
            hls != null -> exo.setMediaItem(
                MediaItem.Builder().setUri(hls).setMimeType(MimeTypes.APPLICATION_M3U8).setMediaMetadata(meta(i)).build(),
            )
            else -> {
                error = "Tidak ada stream yang bisa diputar untuk video ini."
                return
            }
        }
        exo.setPlaybackSpeed(speed)
        exo.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun reload(keepPos: Long) {
        val url = info?.url ?: return
        val h = selected?.height
        loadJob?.cancel()
        loadJob = scope.launch {
            try {
                val i = Repo.load(url)
                info = i
                selected = i.qualities.firstOrNull { it.height == h } ?: pick(i)
                applyMedia(keepPos)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                error = e.message ?: e.toString()
            }
        }
    }

    private fun handleError(e: PlaybackException) {
        val now = System.currentTimeMillis()
        // Satu kali pulih otomatis: URL stream bisa kedaluwarsa -> muat ulang & lanjut dari posisi sama.
        if (!offline && info != null && now - recoverAt > 20_000) {
            recoverAt = now
            reload(exo.currentPosition)
            return
        }
        error = e.errorCodeName + ": " + (e.cause?.message ?: e.message ?: "")
    }

    // ---------- kontrol ----------

    fun togglePlay() {
        if (exo.isPlaying) exo.pause() else {
            if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0)
            exo.play()
        }
    }

    fun seekTo(ms: Long) {
        exo.seekTo(ms.coerceAtLeast(0))
        positionMs = ms.coerceAtLeast(0)
    }

    fun seekBy(deltaMs: Long) = seekTo(exo.currentPosition + deltaMs)

    fun selectQuality(q: StreamChoice) {
        selected = q
        audioOnly = false
        applyMedia()
    }

    fun selectSub(index: Int) {
        subIndex = index
        applyMedia()
    }

    fun changeSpeed(s: Float) {
        speed = s
        exo.setPlaybackSpeed(s)
    }

    fun toggleLoop() {
        loop = !loop
        exo.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun toggleAudioOnly() {
        audioOnly = !audioOnly
        applyMedia()
    }

    fun setSleep(minutes: Int) {
        sleepJob?.cancel()
        when {
            minutes == 0 -> sleepAt = 0L
            minutes < 0 -> sleepAt = -1L
            else -> {
                sleepAt = System.currentTimeMillis() + minutes * 60_000L
                sleepJob = scope.launch {
                    delay(minutes * 60_000L)
                    exo.pause()
                    sleepAt = 0L
                }
            }
        }
    }

    // ---------- antrean ----------

    fun enqueue(v: VideoItem) {
        if (queue.none { it.url == v.url }) queue.add(v)
    }

    fun hasNext(): Boolean = queue.isNotEmpty() || info?.related?.isNotEmpty() == true

    fun next() {
        val n = if (queue.isNotEmpty()) queue.removeAt(0) else info?.related?.firstOrNull()
        if (n != null) open(n.url)
    }

    fun playList(items: List<VideoItem>, start: Int = 0) {
        if (items.isEmpty()) return
        queue.clear()
        queue.addAll(items.drop(start + 1))
        open(items[start].url)
    }

    private fun onEnded() {
        saveProgress(done = true)
        if (sleepAt == -1L) {
            sleepAt = 0L
            return
        }
        if (queue.isNotEmpty() || Settings.autoplay) next()
    }

    fun saveProgress(done: Boolean = false) {
        val i = info ?: return
        if (offline || !active) return
        val d = exo.duration
        val dur = if (d == C.TIME_UNSET || d <= 0) i.duration * 1000 else d
        Local.history.update(i.toItem(), if (done) 0L else exo.currentPosition, dur)
    }

    fun collapse() {
        expanded = false
    }

    fun close() {
        saveProgress()
        loadJob?.cancel()
        sleepJob?.cancel()
        sleepAt = 0L
        exo.stop()
        exo.clearMediaItems()
        info = null
        error = null
        loading = false
        active = false
        expanded = false
        audioOnly = false
        isPlaying = false
    }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, Playback.exo).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = Playback.exo
        if (!p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}
