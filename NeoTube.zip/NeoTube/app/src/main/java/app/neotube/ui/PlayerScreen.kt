package app.neotube.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color as AColor
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.offline.Download as Dl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import app.neotube.data.Library
import app.neotube.data.PlayInfo
import app.neotube.data.Repo
import app.neotube.data.ServiceLocator
import app.neotube.data.StreamChoice
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Video-only + audio-only digabung di pemutar (cara YouTube menyajikan 1440p/4K). */
private fun buildSource(info: PlayInfo, q: StreamChoice): MediaSource {
    val factory = ProgressiveMediaSource.Factory(ServiceLocator.playbackFactory)
    fun prog(url: String, key: String): MediaSource =
        factory.createMediaSource(MediaItem.Builder().setUri(url).setCustomCacheKey(key).build())

    val video = prog(q.url, q.key)
    val au = info.audioUrl
    val ak = info.audioKey
    return if (au != null && ak != null) MergingMediaSource(video, prog(au, ak)) else video
}

@Composable
fun PlayerScreen(target: PlayTarget, onClose: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val downloads by ServiceLocator.downloads.collectAsStateWithLifecycle()

    var info by remember { mutableStateOf<PlayInfo?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var playError by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<StreamChoice?>(null) }
    var fullscreen by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableIntStateOf(0) }
    var showQuality by remember { mutableStateOf(false) }
    var expandDesc by remember { mutableStateOf(false) }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val full = fullscreen || landscape

    val exo = remember {
        ExoPlayer.Builder(ctx, DefaultMediaSourceFactory(ServiceLocator.playbackFactory)).build()
    }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onPlayerError(error: PlaybackException) {
                playError = error.errorCodeName + ": " + (error.cause?.message ?: error.message ?: "")
            }
        }
        exo.addListener(l)
        onDispose {
            exo.removeListener(l)
            exo.release()
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.let { a ->
                a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(a.window, a.window.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
    LaunchedEffect(exo) {
        while (true) {
            posMs = exo.currentPosition
            durMs = exo.duration.let { if (it == C.TIME_UNSET) 0L else it }
            delay(250)
        }
    }

    // Muat info stream (atau data offline).
    LaunchedEffect(target, retry) {
        loadError = null
        playError = null
        try {
            val i = when (target) {
                is PlayTarget.Online -> Repo.load(target.url)
                is PlayTarget.Offline -> Repo.offlineInfo(target.entry)
            }
            info = i
            selected = i.qualities.firstOrNull { it.height <= 1080 } ?: i.qualities.firstOrNull()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            loadError = e.message ?: e.toString()
        }
    }

    // Putar / ganti kualitas (posisi dipertahankan).
    LaunchedEffect(info, selected) {
        val i = info ?: return@LaunchedEffect
        val q = selected
        val pos = if (exo.mediaItemCount > 0) exo.currentPosition else 0L
        playError = null
        val hls = i.hlsUrl
        when {
            q != null -> exo.setMediaSource(buildSource(i, q), pos)
            hls != null -> exo.setMediaItem(MediaItem.Builder().setUri(hls).setMimeType(MimeTypes.APPLICATION_M3U8).build())
            else -> {
                playError = "Tidak ada stream yang bisa diputar untuk video ini."
                return@LaunchedEffect
            }
        }
        exo.prepare()
        exo.playWhenReady = true
    }

    // Kontrol melayang hilang sendiri.
    LaunchedEffect(controls, isPlaying, touch, showQuality) {
        if (controls && isPlaying && !showQuality) {
            delay(3500)
            controls = false
        }
    }

    // Layar penuh: kunci landscape + sembunyikan system bar.
    LaunchedEffect(full) {
        val w = activity?.window ?: return@LaunchedEffect
        val c = WindowCompat.getInsetsController(w, w.decorView)
        if (full) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    LaunchedEffect(landscape, fullscreen) {
        if (!landscape && !fullscreen) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    fun toggleFullscreen() {
        if (full) {
            fullscreen = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            fullscreen = true
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }
    fun close() {
        exo.pause()
        onClose()
    }
    BackHandler { if (full) toggleFullscreen() else close() }

    val i = info
    val q = selected

    val surface: @Composable (Modifier) -> Unit = { mod ->
        VideoSurface(
            modifier = mod,
            exo = exo,
            isPlaying = isPlaying,
            buffering = buffering,
            posMs = posMs,
            durMs = durMs,
            controls = controls,
            error = playError ?: loadError,
            qualityLabel = q?.let { it.label + if (it.tag.isNotEmpty()) " " + it.tag else "" } ?: "Auto",
            full = full,
            showQuality = showQuality && i != null && i.qualities.size > 1,
            qualities = i?.qualities ?: emptyList(),
            selected = q,
            onToggle = { controls = !controls; touch++ },
            onBack = { if (full) toggleFullscreen() else close() },
            onFullscreen = { toggleFullscreen() },
            onQualityButton = { showQuality = !showQuality; touch++ },
            onSelectQuality = { showQuality = false; selected = it },
            onRetry = { if (loadError != null || info == null) retry++ else { playError = null; exo.prepare() } },
            onInteract = { touch++; controls = true },
        )
    }

    Box(Modifier.fillMaxSize().background(Ink)) {
        AuroraBackground()
        if (full) {
            surface(Modifier.fillMaxSize())
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                surface(Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 14.dp, bottom = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (i == null) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(vertical = 36.dp), contentAlignment = Alignment.Center) {
                                if (loadError == null) CircularProgressIndicator(color = Cyan, strokeWidth = 3.dp)
                            }
                        }
                    } else {
                        item {
                            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(i.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 26.sp)
                                val meta = listOf(
                                    i.uploader,
                                    if (i.views >= 0) fmtCount(i.views) + " x ditonton" else "",
                                    if (i.likes >= 0) fmtCount(i.likes) + " suka" else "",
                                ).filter { it.isNotBlank() }.joinToString(" • ")
                                Text(meta, color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp)
                            }
                        }
                        if (!i.offline) {
                            item {
                                val parts = if (q != null) listOfNotNull(downloads[q.key], i.audioKey?.let { downloads[it] }) else emptyList()
                                val expected = if (i.audioKey != null) 2 else 1
                                val done = parts.size == expected && parts.all { it.state == Dl.STATE_COMPLETED }
                                val active = parts.isNotEmpty() && !done && parts.none { it.state == Dl.STATE_FAILED }
                                val pct = if (parts.isEmpty()) 0 else parts.map { it.percentDownloaded.coerceAtLeast(0f) }.average().toInt()
                                val est = if (q != null && q.bitrate > 0 && i.duration > 0) (q.bitrate + i.audioBitrate * 1000L) * i.duration / 8 else 0L
                                val label = when {
                                    q == null -> "Tidak tersedia"
                                    done -> "Tersimpan di perangkat"
                                    active -> "Mengunduh $pct%"
                                    else -> "Unduh ${q.label}" + if (est > 0) "  (±${fmtBytes(est)})" else ""
                                }
                                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    GlassCard(
                                        Modifier.weight(1f),
                                        shape = RoundedCornerShape(26.dp),
                                        fill = if (done) MintFill else AccentFill,
                                        onClick = if (q == null || done || active) null else ({ Library.startDownload(ctx, i, q) }),
                                    ) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(vertical = 14.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Icon(if (done) Icons.Rounded.DownloadDone else Icons.Rounded.Download, null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                        }
                                    }
                                    GlassIconButton(
                                        Icons.Rounded.Share,
                                        {
                                            val send = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, "https://youtu.be/" + i.videoId)
                                            }
                                            ctx.startActivity(Intent.createChooser(send, null))
                                        },
                                        size = 50.dp,
                                    )
                                }
                            }
                        }
                        if (i.qualities.size > 1) {
                            item { QualityRow(i.qualities, q) { selected = it } }
                        }
                        if (i.description.isNotBlank()) {
                            item {
                                GlassCard(
                                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                    shape = RoundedCornerShape(22.dp),
                                    onClick = { expandDesc = !expandDesc },
                                ) {
                                    Text(
                                        i.description,
                                        Modifier.padding(16.dp),
                                        color = Color.White.copy(alpha = 0.8f),
                                        fontSize = 14.sp,
                                        maxLines = if (expandDesc) Int.MAX_VALUE else 3,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                        if (i.related.isNotEmpty()) {
                            item {
                                Text(
                                    "Video terkait",
                                    Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                                )
                            }
                            items(i.related) { v ->
                                VideoCard(v, onClick = { onOpen(v.url) }, compact = true, modifier = Modifier.padding(horizontal = 16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QualityRow(list: List<StreamChoice>, selected: StreamChoice?, onSelect: (StreamChoice) -> Unit) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
    ) {
        items(list) { c ->
            val sel = c.key == selected?.key
            GlassCard(
                shape = RoundedCornerShape(50),
                fill = if (sel) AccentFill else GlassFill,
                onClick = { onSelect(c) },
            ) {
                Text(
                    c.label + if (c.tag.isNotEmpty()) " " + c.tag else "",
                    Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                    color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun VideoSurface(
    modifier: Modifier,
    exo: ExoPlayer,
    isPlaying: Boolean,
    buffering: Boolean,
    posMs: Long,
    durMs: Long,
    controls: Boolean,
    error: String?,
    qualityLabel: String,
    full: Boolean,
    showQuality: Boolean,
    qualities: List<StreamChoice>,
    selected: StreamChoice?,
    onToggle: () -> Unit,
    onBack: () -> Unit,
    onFullscreen: () -> Unit,
    onQualityButton: () -> Unit,
    onSelectQuality: (StreamChoice) -> Unit,
    onRetry: () -> Unit,
    onInteract: () -> Unit,
) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    Box(modifier.background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    player = exo
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShutterBackgroundColor(AColor.BLACK)
                }
            },
            update = { it.keepScreenOn = isPlaying },
            modifier = Modifier.fillMaxSize(),
        )
        // Lapisan sentuh di atas PlayerView: ketuk = tampil/sembunyi kontrol.
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onToggle,
            ),
        )
        if (buffering && error == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center).size(38.dp), color = Cyan, strokeWidth = 3.dp)
        }

        AnimatedVisibility(
            visible = controls || error != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize(),
        ) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent, Color.Black.copy(alpha = 0.72f))),
                ),
            ) {
                Row(
                    Modifier.align(Alignment.TopStart).fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    GlassIconButton(Icons.Rounded.KeyboardArrowDown, onBack, size = 42.dp)
                    GlassCard(shape = RoundedCornerShape(50), fill = GlassDark, onClick = onQualityButton) {
                        Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Tune, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(qualityLabel, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                if (error != null) {
                    Column(
                        Modifier.align(Alignment.Center).padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text("Video tidak bisa diputar", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(error, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                        GlassCard(shape = RoundedCornerShape(50), fill = AccentFill, onClick = onRetry) {
                            Text("Coba lagi", Modifier.padding(horizontal = 22.dp, vertical = 10.dp), color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    Row(
                        Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(26.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        GlassIconButton(Icons.Rounded.Replay10, { exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)); onInteract() }, size = 46.dp)
                        GlassIconButton(
                            if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            { if (exo.isPlaying) exo.pause() else exo.play(); onInteract() },
                            size = 64.dp, fill = AccentFill,
                        )
                        GlassIconButton(Icons.Rounded.Forward10, { exo.seekTo(exo.currentPosition + 10_000); onInteract() }, size = 46.dp)
                    }
                }

                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = if (full) 8.dp else 2.dp)) {
                    if (showQuality) {
                        Box(Modifier.padding(bottom = 6.dp)) {
                            QualityRow(qualities, selected, onSelectQuality)
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(fmtDur(posMs / 1000), color = Color.White, fontSize = 12.sp)
                        val progress = if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f
                        Slider(
                            value = if (dragging) dragValue else progress,
                            onValueChange = { dragging = true; dragValue = it; onInteract() },
                            onValueChangeFinished = {
                                exo.seekTo((dragValue * durMs).toLong())
                                dragging = false
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Cyan,
                                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
                            ),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                        )
                        Text(fmtDur(durMs / 1000), color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            if (full) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                            contentDescription = "Layar penuh",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp).clickable { onFullscreen() },
                        )
                    }
                }
            }
        }
    }
}
