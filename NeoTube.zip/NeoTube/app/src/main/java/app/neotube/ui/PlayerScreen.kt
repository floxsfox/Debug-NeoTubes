package app.neotube.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color as AColor
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.WatchLater
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.exoplayer.offline.Download as Dl
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import app.neotube.data.CommentItem
import app.neotube.data.Library
import app.neotube.data.Local
import app.neotube.data.Playback
import app.neotube.data.Repo
import app.neotube.data.ServiceLocator
import app.neotube.data.Sub
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun PlayerScreen() {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    var fullscreen by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableIntStateOf(0) }
    var sheet by remember { mutableStateOf(false) }
    var resize by remember { mutableIntStateOf(0) }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val full = fullscreen || landscape

    DisposableEffect(Unit) {
        onDispose {
            activity?.let { a ->
                a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(a.window, a.window.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
    LaunchedEffect(full, Playback.inPip) {
        val w = activity?.window ?: return@LaunchedEffect
        val c = WindowCompat.getInsetsController(w, w.decorView)
        if (full || Playback.inPip) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    LaunchedEffect(landscape, fullscreen) {
        if (!landscape && !fullscreen) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
    LaunchedEffect(controls, Playback.isPlaying, touch, sheet) {
        if (controls && Playback.isPlaying && !sheet) {
            delay(3500)
            controls = false
        }
    }

    fun toggleFullscreen() {
        if (full) {
            fullscreen = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            fullscreen = true
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }
    BackHandler(enabled = !Playback.inPip) { if (full) toggleFullscreen() else Playback.collapse() }

    if (Playback.inPip) {
        Box(Modifier.fillMaxSize().background(Color.Black)) { PlayerViewHost(Modifier.fillMaxSize(), 0) }
    } else {
        Box(Modifier.fillMaxSize().background(Ink)) {
            AuroraBackground()
            if (full) {
                VideoSurface(
                    Modifier.fillMaxSize(), true, controls, resize, activity,
                    onToggle = { controls = !controls; touch++ },
                    onBack = { toggleFullscreen() },
                    onFullscreen = { toggleFullscreen() },
                    onSettings = { sheet = true },
                    onInteract = { controls = true; touch++ },
                )
            } else {
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    VideoSurface(
                        Modifier.fillMaxWidth().aspectRatio(16f / 9f), false, controls, resize, activity,
                        onToggle = { controls = !controls; touch++ },
                        onBack = { Playback.collapse() },
                        onFullscreen = { toggleFullscreen() },
                        onSettings = { sheet = true },
                        onInteract = { controls = true; touch++ },
                    )
                    PlayerDetails(Modifier.fillMaxSize())
                }
            }
            PlayerSettingsSheet(sheet, { sheet = false }, resize) { resize = it }
        }
    }
}

@Composable
private fun PlayerViewHost(modifier: Modifier, resize: Int) {
    val exo = Playback.exo
    AndroidView(
        factory = { c ->
            PlayerView(c).apply {
                useController = false
                player = exo
                setShutterBackgroundColor(AColor.BLACK)
            }
        },
        modifier = modifier,
        update = { v ->
            v.keepScreenOn = Playback.isPlaying
            v.resizeMode = when (resize) {
                1 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                2 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        },
        onRelease = { it.player = null },
    )
}

@Composable
private fun VideoSurface(
    modifier: Modifier,
    full: Boolean,
    controls: Boolean,
    resize: Int,
    activity: Activity?,
    onToggle: () -> Unit,
    onBack: () -> Unit,
    onFullscreen: () -> Unit,
    onSettings: () -> Unit,
    onInteract: () -> Unit,
) {
    val ctx = LocalContext.current
    val info = Playback.info
    val err = Playback.error
    val busy = Playback.loading || (Playback.buffering && err == null)
    var hud by remember { mutableStateOf<String?>(null) }
    var hudTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(hudTick) {
        if (hud != null) {
            delay(800)
            hud = null
        }
    }

    Box(modifier.background(Color.Black)) {
        if (Playback.audioOnly) {
            Box(Modifier.fillMaxSize()) {
                AsyncImage(
                    model = info?.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                    alpha = 0.3f, modifier = Modifier.fillMaxSize(),
                )
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Headphones, null, tint = Cyan, modifier = Modifier.size(34.dp))
                    Text("Mode audio", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        } else {
            PlayerViewHost(Modifier.fillMaxSize(), resize)
        }

        // Lapisan gestur: ketuk = kontrol, ketuk dua kali = ±10 dtk, geser kiri = kecerahan, geser kanan = volume.
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { onToggle() },
                        onDoubleTap = { o ->
                            val left = o.x < size.width / 2f
                            Playback.seekBy(if (left) -10_000L else 10_000L)
                            hud = if (left) "−10 dtk" else "+10 dtk"
                            hudTick++
                        },
                    )
                }
                .pointerInput(Unit) {
                    var leftSide = true
                    var vol = 0f
                    detectVerticalDragGestures(
                        onDragStart = { o ->
                            leftSide = o.x < size.width / 2f
                            val am = ctx.getSystemService(AudioManager::class.java)
                            vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                        },
                        onVerticalDrag = { change, dy ->
                            change.consume()
                            val d = -dy / size.height * 1.5f
                            if (leftSide) {
                                val w = activity?.window
                                if (w != null) {
                                    val a = w.attributes
                                    val cur = if (a.screenBrightness < 0f) 0.5f else a.screenBrightness
                                    val nb = (cur + d).coerceIn(0.02f, 1f)
                                    a.screenBrightness = nb
                                    w.attributes = a
                                    hud = "Kecerahan " + (nb * 100).toInt() + "%"
                                    hudTick++
                                }
                            } else {
                                val am = ctx.getSystemService(AudioManager::class.java)
                                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                vol = (vol + d * max).coerceIn(0f, max.toFloat())
                                am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                                hud = "Volume " + (vol / max * 100).toInt() + "%"
                                hudTick++
                            }
                        },
                    )
                },
        )

        if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center).size(38.dp), color = Cyan, strokeWidth = 3.dp)

        AnimatedVisibility(hud != null, Modifier.align(Alignment.TopCenter).padding(top = 60.dp), enter = fadeIn(), exit = fadeOut()) {
            GlassCard(Modifier, RoundedCornerShape(50), GlassDark) {
                Text(hud ?: "", Modifier.padding(horizontal = 18.dp, vertical = 9.dp), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        AnimatedVisibility(controls || err != null, Modifier.fillMaxSize(), enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.65f), Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.78f))),
                ),
            ) {
                // Bar atas
                Row(
                    Modifier.align(Alignment.TopStart).fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    GlassIconButton(Icons.Rounded.KeyboardArrowDown, onBack, size = 40.dp)
                    if (full && info != null) {
                        Text(info.title, Modifier.weight(1f), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else Spacer(Modifier.weight(1f))
                    if (info != null && info.subs.isNotEmpty()) {
                        GlassIconButton(
                            Icons.Rounded.ClosedCaption,
                            {
                                if (Playback.subIndex >= 0) Playback.selectSub(-1) else Playback.selectSub(0)
                                onInteract()
                            },
                            size = 40.dp, fill = if (Playback.subIndex >= 0) AccentFill else GlassDark,
                        )
                    }
                    GlassIconButton(Icons.Rounded.Settings, onSettings, size = 40.dp)
                }

                if (err != null) {
                    Column(
                        Modifier.align(Alignment.Center).padding(horizontal = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("Video tidak bisa diputar", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(err, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = 15.sp)
                        GlassCard(Modifier, RoundedCornerShape(50), AccentFill, { Playback.retry() }) {
                            Text("Coba lagi", Modifier.padding(horizontal = 24.dp, vertical = 9.dp), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }
                } else {
                    if (!busy) {
                        Row(
                            Modifier.align(Alignment.Center),
                            horizontalArrangement = Arrangement.spacedBy(22.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            GlassIconButton(Icons.Rounded.Replay10, { Playback.seekBy(-10_000L); onInteract() }, size = 44.dp)
                            GlassIconButton(
                                if (Playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                { Playback.togglePlay(); onInteract() }, size = 60.dp, fill = AccentFill,
                            )
                            GlassIconButton(Icons.Rounded.Forward10, { Playback.seekBy(10_000L); onInteract() }, size = 44.dp)
                            if (Playback.hasNext()) GlassIconButton(Icons.Rounded.SkipNext, { Playback.next() }, size = 44.dp)
                        }
                    }
                    // Bar bawah: seekbar + waktu + bab + layar penuh
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 14.dp)) {
                        SeekBar(
                            posMs = Playback.positionMs, durMs = Playback.durationMs, bufMs = Playback.bufferedMs,
                            chapters = info?.chapters ?: emptyList(),
                            onSeek = { Playback.seekTo(it) }, onInteract = onInteract,
                        )
                        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                fmtDur(Playback.positionMs / 1000) + " / " + fmtDur(Playback.durationMs / 1000),
                                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                            )
                            val ch = chapterAt(info?.chapters ?: emptyList(), Playback.positionMs / 1000)
                            Text(
                                ch?.title ?: "", Modifier.weight(1f).padding(horizontal = 12.dp),
                                color = Cyan, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                            )
                            Icon(
                                if (full) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen, "Layar penuh", tint = Color.White,
                                modifier = Modifier.size(34.dp).clip(CircleShape).clickable { onFullscreen() }.padding(5.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------- detail di bawah video ----------------

@Composable
private fun PlayerDetails(modifier: Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val info = Playback.info
    val dls by ServiceLocator.downloads.collectAsStateWithLifecycle()
    val liked by Local.liked.items.collectAsStateWithLifecycle()
    val later by Local.watchLater.items.collectAsStateWithLifecycle()
    val subs by Local.subs.items.collectAsStateWithLifecycle()
    var expandDesc by remember(info?.url) { mutableStateOf(false) }
    var comments by remember(info?.url) { mutableStateOf<List<CommentItem>?>(null) }
    var cLoading by remember(info?.url) { mutableStateOf(false) }
    var cError by remember(info?.url) { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier,
        contentPadding = PaddingValues(top = 14.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (info == null) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 36.dp), contentAlignment = Alignment.Center) {
                    if (Playback.loading) CircularProgressIndicator(color = Cyan, strokeWidth = 3.dp)
                }
            }
        } else {
            val me = info.toItem()

            item {
                Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(info.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 26.sp)
                    val meta = listOf(
                        if (info.views >= 0) fmtCount(info.views) + " x ditonton" else "",
                        if (info.likes >= 0) fmtCount(info.likes) + " suka" else "",
                    ).filter { it.isNotBlank() }.joinToString(" • ")
                    if (meta.isNotBlank()) Text(meta, color = TextDim, fontSize = 13.sp)
                }
            }

            item {
                val isLiked = liked.any { it.url == me.url }
                val isLater = later.any { it.url == me.url }
                val q = Playback.selected
                val parts = if (q != null) listOfNotNull(dls[q.key], info.audioKey?.let { dls[it] }) else emptyList()
                val expected = if (info.audioKey != null) 2 else 1
                val done = parts.size == expected && parts.all { it.state == Dl.STATE_COMPLETED }
                val active = parts.isNotEmpty() && !done && parts.none { it.state == Dl.STATE_FAILED }
                val pct: Int = if (parts.isEmpty()) 0 else parts.map { it.percentDownloaded.coerceAtLeast(0f) }.average().toInt()

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
                    item {
                        GlassChip(if (isLiked) "Disukai" else "Suka", isLiked, {
                            val now = Local.liked.toggle(me)
                            UiState.toast(if (now) "Ditambahkan ke Disukai" else "Dihapus dari Disukai")
                        }, icon = if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder)
                    }
                    item {
                        GlassChip(if (isLater) "Tersimpan" else "Nanti", isLater, {
                            val now = Local.watchLater.toggle(me)
                            UiState.toast(if (now) "Disimpan ke Tonton nanti" else "Dihapus dari Tonton nanti")
                        }, icon = Icons.Rounded.WatchLater)
                    }
                    item { GlassChip("Antre", false, { Playback.enqueue(me); UiState.toast("Ditambahkan ke antrean") }, icon = Icons.Rounded.PlaylistPlay) }
                    item { GlassChip("Playlist", false, { UiState.pickVideo = me }, icon = Icons.Rounded.PlaylistAdd) }
                    if (!info.offline && q != null) {
                        item {
                            GlassChip(
                                when {
                                    done -> "Tersimpan offline"
                                    active -> "Mengunduh $pct%"
                                    else -> "Unduh " + q.label
                                },
                                done || active,
                                { if (!done && !active) Library.startDownload(ctx, info, q) },
                                icon = if (done) Icons.Rounded.DownloadDone else Icons.Rounded.Download,
                            )
                        }
                    }
                    item { GlassChip("Bagikan", false, { shareText(ctx, info.url) }, icon = Icons.Rounded.Share) }
                    item {
                        GlassChip("Bagikan dari menit ini", false, {
                            shareText(ctx, info.url + "&t=" + (Playback.positionMs / 1000))
                        }, icon = Icons.Rounded.Schedule)
                    }
                    item { GlassChip("Salin tautan", false, { copyText(ctx, info.url) }, icon = Icons.Rounded.ContentCopy) }
                    item { GlassChip("Buka di YouTube", false, { openInYouTube(ctx, info.url) }, icon = Icons.Rounded.OpenInNew) }
                }
            }

            val chUrl = info.uploaderUrl
            if (chUrl != null) {
                item {
                    GlassCard(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp),
                        onClick = { Playback.collapse(); Nav.push(Screen.Channel(chUrl)) },
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Avatar(info.uploaderAvatar, 44.dp)
                            Text(info.uploader, Modifier.weight(1f), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            SubscribeButton(subs.any { it.url == chUrl }) {
                                val now = Local.subs.toggle(Sub(chUrl, info.uploader, info.uploaderAvatar))
                                UiState.toast(if (now) "Berlangganan ${info.uploader}" else "Berhenti berlangganan")
                            }
                        }
                    }
                }
            }

            if (info.chapters.isNotEmpty()) {
                item { SectionTitle("Bab") }
                item {
                    val cur = chapterAt(info.chapters, Playback.positionMs / 1000)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
                        items(info.chapters) { c ->
                            GlassChip(fmtDur(c.startSec) + "  " + c.title, cur == c, { Playback.seekTo(c.startSec * 1000) })
                        }
                    }
                }
            }

            if (info.description.isNotBlank()) {
                item {
                    GlassCard(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp),
                        onClick = { expandDesc = !expandDesc },
                    ) {
                        Text(
                            info.description, Modifier.padding(16.dp), color = Color.White.copy(alpha = 0.82f), fontSize = 14.sp, lineHeight = 20.sp,
                            maxLines = if (expandDesc) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            if (Playback.queue.isNotEmpty()) {
                item { SectionTitle("Antrean (" + Playback.queue.size + ")") }
                items(Playback.queue.toList()) { v ->
                    VideoRow(v, { Playback.open(v.url) }, Modifier.padding(horizontal = 16.dp),
                        trailing = { SmallIcon(Icons.Rounded.Close) { Playback.queue.remove(v) } })
                }
            }

            if (!info.offline) {
                item {
                    GlassCard(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp),
                        onClick = {
                            if (comments == null && !cLoading) {
                                cLoading = true
                                cError = null
                                scope.launch {
                                    try {
                                        comments = Repo.comments(info.url)
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Throwable) {
                                        cError = "Komentar tidak tersedia untuk video ini"
                                    }
                                    cLoading = false
                                }
                            }
                        },
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Komentar", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            val cl = comments
                            Text(
                                when {
                                    cLoading -> "Memuat…"
                                    cError != null -> cError ?: ""
                                    cl != null -> if (cl.isEmpty()) "Belum ada komentar" else "${cl.size} komentar teratas"
                                    else -> "Ketuk untuk memuat"
                                },
                                color = TextDim, fontSize = 13.sp,
                            )
                        }
                    }
                }
                val cl = comments
                if (cl != null) {
                    items(cl.take(25)) { c -> CommentCard(c) }
                }
            }

            if (info.related.isNotEmpty()) {
                item { SectionTitle("Video terkait") }
                items(info.related) { v ->
                    VideoRow(v, { Playback.open(v.url) }, Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

@Composable
private fun CommentCard(c: CommentItem) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(36.dp).clip(CircleShape).background(Violet.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) {
            Text(c.author.trim().take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                c.author + if (!c.date.isNullOrBlank()) "  •  " + c.date else "",
                color = TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(c.text, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp, maxLines = 6, overflow = TextOverflow.Ellipsis)
            if (c.likes > 0) Text(c.likes.toString() + " suka", color = TextDim, fontSize = 12.sp)
        }
    }
}

// ---------------- sheet pengaturan pemutar ----------------

@Composable
private fun SheetLabel(text: String) {
    Text(text, color = TextDim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun ChipScroll(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
private fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), color = Color.White, fontSize = 15.sp)
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = Violet,
                uncheckedThumbColor = Color.White.copy(alpha = 0.8f), uncheckedTrackColor = Color.White.copy(alpha = 0.15f),
                uncheckedBorderColor = Color.Transparent,
            ),
        )
    }
}

@Composable
private fun PlayerSettingsSheet(visible: Boolean, onDismiss: () -> Unit, resize: Int, onResize: (Int) -> Unit) {
    val info = Playback.info
    GlassSheet(visible, onDismiss) {
        Text("Pengaturan pemutar", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

        if (info != null && info.qualities.isNotEmpty()) {
            SheetLabel("Kualitas")
            ChipScroll {
                info.qualities.forEach { q ->
                    GlassChip(
                        q.label + if (q.tag.isNotEmpty()) " " + q.tag else "",
                        Playback.selected?.key == q.key && !Playback.audioOnly,
                        { Playback.selectQuality(q) },
                    )
                }
            }
        }

        SheetLabel("Kecepatan putar")
        ChipScroll {
            listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                GlassChip(if (s == 1f) "Normal" else s.toString() + "x", Playback.speed == s, { Playback.changeSpeed(s) })
            }
        }

        SheetLabel("Rasio layar")
        ChipScroll {
            listOf("Pas" to 0, "Isi" to 1, "Zoom" to 2).forEach { (l, v) -> GlassChip(l, resize == v, { onResize(v) }) }
        }

        if (info != null && info.subs.isNotEmpty()) {
            SheetLabel("Subtitel")
            ChipScroll {
                GlassChip("Mati", Playback.subIndex == -1, { Playback.selectSub(-1) })
                info.subs.forEachIndexed { i, s -> GlassChip(s.label, Playback.subIndex == i, { Playback.selectSub(i) }) }
            }
        }

        SheetLabel("Timer tidur")
        ChipScroll {
            GlassChip("Mati", Playback.sleepAt == 0L, { Playback.setSleep(0) })
            listOf(15, 30, 60).forEach { m -> GlassChip("$m mnt", false, { Playback.setSleep(m); UiState.toast("Berhenti dalam $m menit") }) }
            GlassChip("Akhir video", Playback.sleepAt == -1L, { Playback.setSleep(-1) })
        }

        ToggleRow("Ulangi video", Playback.loop) { Playback.toggleLoop() }
        if (info != null && info.audioUrl != null) {
            ToggleRow("Mode audio saja (hemat data)", Playback.audioOnly) { Playback.toggleAudioOnly() }
        }
    }
}
