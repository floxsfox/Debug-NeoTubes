package app.neotube.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.neotube.data.Local
import app.neotube.data.Settings

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize()) {
        BackHeader("Pengaturan", { Nav.pop() })
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = bottomPad()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { SectionTitle("Pemutaran") }
            item {
                GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Kualitas awal", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("Kualitas tertinggi yang dipilih otomatis. 1440p/4K tetap bisa dipilih manual di pemutar.", color = TextDim, fontSize = 12.sp, lineHeight = 17.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0 to "Otomatis", 360 to "360p", 480 to "480p", 720 to "720p", 1080 to "1080p", 1440 to "1440p", 2160 to "4K").forEach { (h, l) ->
                                GlassChip(l, Settings.defaultHeight == h, { Settings.setHeight(h) })
                            }
                        }
                    }
                }
            }
            item { SwitchRow("Hemat data seluler", "Batasi 480p saat memakai data seluler", Settings.dataSaver) { Settings.setDataSaver(it) } }
            item { SwitchRow("Putar otomatis berikutnya", "Lanjut ke antrean / video terkait saat selesai", Settings.autoplay) { Settings.setAutoplay(it) } }
            item { SwitchRow("Lanjutkan dari posisi terakhir", "Buka video di menit terakhir ditonton", Settings.resume) { Settings.setResume(it) } }

            item { SectionTitle("Data") }
            item {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip("Hapus riwayat tonton", false, { Local.history.clear(); UiState.toast("Riwayat tonton dihapus") }, icon = Icons.Rounded.Delete)
                    GlassChip("Hapus riwayat cari", false, { Local.searches.clear(); UiState.toast("Riwayat pencarian dihapus") }, icon = Icons.Rounded.Delete)
                }
            }

            item { SectionTitle("Tentang") }
            item {
                GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("NeoTube 0.2.0", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Klien YouTube tanpa akun. Langganan, riwayat, dan playlist disimpan di perangkat ini saja.", color = TextDim, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(22.dp)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(sub, color = TextDim, fontSize = 12.sp, lineHeight = 17.sp)
            }
            Switch(
                checked = checked, onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White, checkedTrackColor = Violet,
                    uncheckedThumbColor = Color.White.copy(alpha = 0.8f), uncheckedTrackColor = Color.White.copy(alpha = 0.15f),
                    uncheckedBorderColor = Color.Transparent,
                ),
            )
        }
    }
}
