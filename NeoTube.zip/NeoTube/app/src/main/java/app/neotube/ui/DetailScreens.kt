package app.neotube.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.neotube.data.ChannelPage
import app.neotube.data.Local
import app.neotube.data.Playback
import app.neotube.data.PlaylistPage
import app.neotube.data.Repo
import app.neotube.data.Sub
import app.neotube.data.VideoItem
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

@Composable
private fun Spinner() {
    Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Cyan, strokeWidth = 3.dp)
    }
}

@Composable
private fun ErrorCard(text: String, onRetry: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), onClick = onRetry) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Gagal memuat", color = Color.White, fontWeight = FontWeight.Bold)
            Text(text, color = TextDim, fontSize = 13.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
            Text("Ketuk untuk coba lagi", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ---------------- Kanal ----------------

@Composable
fun ChannelScreen(url: String) {
    var page by remember { mutableStateOf<ChannelPage?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val subs by Local.subs.items.collectAsStateWithLifecycle()

    LaunchedEffect(url, tick) {
        error = null
        try { page = Repo.channel(url) } catch (e: CancellationException) { throw e } catch (e: Throwable) { error = e.message ?: e.toString() }
    }

    Column(Modifier.fillMaxSize()) {
        BackHeader(page?.name ?: "Kanal", { Nav.pop() })
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = bottomPad()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            val p = page
            if (p == null && error == null) item { Spinner() }
            val err = error
            if (err != null) item { ErrorCard(err) { tick++ } }
            if (p != null) {
                item {
                    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(26.dp)) {
                        Column {
                            if (p.banner != null) {
                                AsyncImage(
                                    model = p.banner, contentDescription = null, contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 5f),
                                )
                            }
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    Avatar(p.avatar, 64.dp)
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(p.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        if (p.subs >= 0) Text(fmtCount(p.subs) + " pelanggan", color = TextDim, fontSize = 13.sp)
                                    }
                                }
                                SubscribeButton(subs.any { it.url == url }) {
                                    val now = Local.subs.toggle(Sub(url, p.name, p.avatar))
                                    UiState.toast(if (now) "Berlangganan ${p.name}" else "Berhenti berlangganan")
                                }
                                if (p.desc.isNotBlank()) Text(p.desc, color = TextDim, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 19.sp)
                            }
                        }
                    }
                }
                if (p.videos.isNotEmpty()) {
                    item {
                        Row(Modifier.padding(horizontal = 16.dp)) {
                            GlassChip("Putar semua", true, { Playback.playList(p.videos) }, icon = Icons.Rounded.PlayArrow)
                        }
                    }
                }
                items(p.videos) { v ->
                    VideoCard(v, { Playback.open(v.url) }, Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

// ---------------- Playlist YouTube ----------------

@Composable
fun PlaylistScreen(url: String) {
    var page by remember { mutableStateOf<PlaylistPage?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(url, tick) {
        error = null
        try { page = Repo.playlist(url) } catch (e: CancellationException) { throw e } catch (e: Throwable) { error = e.message ?: e.toString() }
    }

    Column(Modifier.fillMaxSize()) {
        BackHeader(page?.name ?: "Playlist", { Nav.pop() })
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = bottomPad()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            val p = page
            if (p == null && error == null) item { Spinner() }
            val err = error
            if (err != null) item { ErrorCard(err) { tick++ } }
            if (p != null) {
                item {
                    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("${p.uploader} • ${p.items.size} video", color = TextDim, fontSize = 14.sp)
                        Row { GlassChip("Putar semua", true, { Playback.playList(p.items) }, icon = Icons.Rounded.PlayArrow) }
                    }
                }
                items(p.items.size) { i ->
                    val v = p.items[i]
                    VideoRow(v, { Playback.playList(p.items, i) }, Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

// ---------------- Playlist buatan sendiri ----------------

@Composable
fun UserPlaylistScreen(id: String) {
    val lists by Local.playlists.items.collectAsStateWithLifecycle()
    val pl = lists.firstOrNull { it.id == id }

    Column(Modifier.fillMaxSize()) {
        BackHeader(pl?.name ?: "Playlist", { Nav.pop() }) {
            if (pl != null) GlassIconButton(Icons.Rounded.Delete, { Local.playlists.delete(id); Nav.pop(); UiState.toast("Playlist dihapus") }, size = 42.dp)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = bottomPad()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (pl == null || pl.items.isEmpty()) {
                item { EmptyState(Icons.Rounded.PlayArrow, "Playlist kosong", "Tambahkan video dari menu ⋮ di tiap video.") }
            } else {
                item { Row(Modifier.padding(horizontal = 16.dp)) { GlassChip("Putar semua", true, { Playback.playList(pl.items) }, icon = Icons.Rounded.PlayArrow) } }
                items(pl.items.size) { i ->
                    val v = pl.items[i]
                    VideoRow(v, { Playback.playList(pl.items, i) }, Modifier.padding(horizontal = 16.dp),
                        trailing = { SmallIcon(Icons.Rounded.Close) { Local.playlists.remove(id, v.url) } })
                }
            }
        }
    }
}

// ---------------- Langganan ----------------

object SubsState {
    var feed by mutableStateOf<List<VideoItem>>(emptyList())
    var loading by mutableStateOf(false)
    var key by mutableStateOf("")
    var reload by mutableIntStateOf(0)
    val listState = LazyListState()
}

@Composable
fun SubsScreen() {
    val subs by Local.subs.items.collectAsStateWithLifecycle()
    val keyNow = subs.joinToString(",") { it.url }

    LaunchedEffect(keyNow, SubsState.reload) {
        if (subs.isEmpty()) {
            SubsState.feed = emptyList()
            SubsState.key = ""
            return@LaunchedEffect
        }
        if (SubsState.key == keyNow) return@LaunchedEffect
        SubsState.loading = true
        val lists = coroutineScope {
            subs.take(15).map { s ->
                async {
                    try { Repo.channelVideos(s.url, 4) } catch (e: CancellationException) { throw e } catch (e: Throwable) { emptyList<VideoItem>() }
                }
            }.awaitAll()
        }
        // Gabung bergiliran supaya tiap kanal kebagian tempat di atas.
        val total = lists.sumOf { it.size }
        val merged = ArrayList<VideoItem>()
        var i = 0
        while (merged.size < total) {
            lists.forEach { l -> if (i < l.size) merged.add(l[i]) }
            i++
        }
        SubsState.feed = merged.distinctBy { it.url }
        SubsState.key = keyNow
        SubsState.loading = false
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        state = SubsState.listState,
        contentPadding = PaddingValues(top = topPad(), bottom = bottomPad()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            ScreenHeader("Langganan") {
                if (subs.isNotEmpty()) GlassIconButton(Icons.Rounded.Refresh, { SubsState.key = ""; SubsState.reload++ }, size = 42.dp)
            }
        }
        if (subs.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.Subscriptions, "Belum ada langganan",
                    "Cari kanal di Beranda (filter Kanal) lalu ketuk Langganan. Video terbaru semua kanal muncul di sini.",
                )
            }
        } else {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(horizontal = 20.dp)) {
                    items(subs) { s ->
                        Column(
                            Modifier.width(68.dp).clip(RoundedCornerShape(16.dp)).clickable { Nav.push(Screen.Channel(s.url)) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Avatar(s.avatar, 56.dp)
                            Text(s.name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            if (SubsState.loading) item { Spinner() }
            items(SubsState.feed) { v ->
                VideoCard(v, { Playback.open(v.url) }, Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}
