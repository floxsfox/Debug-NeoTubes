package app.neotube.data

import android.media.MediaCodecList
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream

data class VideoItem(
    val url: String,
    val title: String,
    val uploader: String,
    val thumb: String?,
    val duration: Long,
    val views: Long,
    val uploaded: String?,
)

data class StreamChoice(
    val height: Int,
    val label: String,
    val tag: String,
    val url: String,
    val key: String,
    val bitrate: Long,
)

data class PlayInfo(
    val videoId: String,
    val title: String,
    val uploader: String,
    val views: Long,
    val likes: Long,
    val duration: Long,
    val description: String,
    val thumb: String?,
    val qualities: List<StreamChoice>,
    val audioUrl: String?,
    val audioKey: String?,
    val audioBitrate: Int,
    val hlsUrl: String?,
    val related: List<VideoItem>,
    val offline: Boolean = false,
)

object Repo {
    private val yt get() = ServiceList.YouTube

    suspend fun search(query: String): List<VideoItem> = withContext(Dispatchers.IO) {
        val handler = yt.searchQHFactory.fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        SearchInfo.getInfo(yt, handler).relatedItems
            .filterIsInstance<StreamInfoItem>()
            .map { it.toItem() }
    }

    suspend fun load(url: String): PlayInfo = withContext(Dispatchers.IO) {
        val info = StreamInfo.getInfo(url)
        val id = info.id

        // Video-only (adaptif) = jalur untuk 1440p / 4K; digabung dengan audio terbaik saat diputar.
        val qualities = info.videoOnlyStreams
            .filter { it.isUrl && it.height > 0 && !it.content.isNullOrBlank() }
            .groupBy { it.height }
            .mapNotNull { (h, list) ->
                list.filter { decoderOk(it) }
                    .sortedWith(
                        compareBy<VideoStream> { rank(family(it.codec), h) }
                            .thenByDescending { it.bitrate },
                    )
                    .firstOrNull()
                    ?.let { s ->
                        StreamChoice(
                            height = h,
                            label = label(h, s.fps),
                            tag = if (h > 1080) family(s.codec) else "",
                            url = s.content,
                            key = "$id|v|$h|${s.fps}|${s.codec}|${s.bitrate}",
                            bitrate = s.bitrate.toLong(),
                        )
                    }
            }
            .sortedByDescending { it.height }

        val audio = info.audioStreams
            .filter { it.isUrl && !it.content.isNullOrBlank() }
            .maxByOrNull { (if (it.format?.suffix == "m4a") 1_000_000 else 0) + it.averageBitrate }

        // Cadangan: stream gabungan (maks ~720p) kalau tidak ada stream adaptif.
        val finalQualities = if (qualities.isNotEmpty()) qualities else {
            info.videoStreams
                .filter { it.isUrl && !it.content.isNullOrBlank() }
                .maxByOrNull { it.height }
                ?.let { s ->
                    listOf(
                        StreamChoice(
                            s.height, label(s.height, s.fps), "", s.content,
                            "$id|m|${s.height}|${s.codec}", s.bitrate.toLong(),
                        ),
                    )
                } ?: emptyList()
        }
        val muxedOnly = qualities.isEmpty()

        PlayInfo(
            videoId = id,
            title = info.name ?: "",
            uploader = info.uploaderName ?: "",
            views = info.viewCount,
            likes = info.likeCount,
            duration = info.duration,
            description = (info.description?.content ?: "").replace(Regex("<[^>]*>"), "").trim(),
            thumb = info.thumbnails.maxByOrNull { it.height }?.url,
            qualities = finalQualities,
            audioUrl = if (muxedOnly) null else audio?.content,
            audioKey = if (muxedOnly || audio == null) null else "$id|a|${audio.format?.suffix}|${audio.averageBitrate}",
            audioBitrate = audio?.averageBitrate ?: 0,
            hlsUrl = info.hlsUrl?.takeIf { it.isNotBlank() },
            related = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toItem() },
        )
    }

    fun offlineInfo(e: LibEntry): PlayInfo {
        fun fake(key: String) = "https://offline.neotube.invalid/" + Uri.encode(key)
        return PlayInfo(
            videoId = e.videoId, title = e.title, uploader = e.uploader, views = -1, likes = -1,
            duration = e.duration, description = "", thumb = e.thumb,
            qualities = listOf(StreamChoice(e.height, e.label, "", fake(e.vKey), e.vKey, 0)),
            audioUrl = e.aKey?.let { fake(it) }, audioKey = e.aKey, audioBitrate = 0,
            hlsUrl = null, related = emptyList(), offline = true,
        )
    }

    private fun StreamInfoItem.toItem() = VideoItem(
        url = url,
        title = name ?: "",
        uploader = uploaderName ?: "",
        thumb = thumbnails.maxByOrNull { it.height }?.url,
        duration = duration,
        views = viewCount,
        uploaded = textualUploadDate,
    )

    private fun family(codec: String?): String = when {
        codec == null -> "?"
        codec.startsWith("avc") -> "AVC"
        codec.startsWith("vp9") || codec.startsWith("vp09") -> "VP9"
        codec.startsWith("av01") -> "AV1"
        codec.startsWith("hev") || codec.startsWith("hvc") -> "HEVC"
        else -> "?"
    }

    // <=1080p: utamakan AVC (decoder hardware ada di mana-mana). >1080p: VP9 dulu, lalu AV1.
    private fun rank(f: String, h: Int): Int =
        if (h <= 1080) when (f) { "AVC" -> 0; "VP9" -> 1; "AV1" -> 2; else -> 3 }
        else when (f) { "VP9" -> 0; "AV1" -> 1; "HEVC" -> 2; "AVC" -> 3; else -> 4 }

    private fun label(h: Int, fps: Int): String {
        val base = when {
            h >= 4320 -> "8K"
            h >= 2160 -> "4K"
            else -> "${h}p"
        }
        return if (fps > 30) "$base$fps" else base
    }

    /** Sembunyikan kualitas yang tidak bisa di-decode perangkat (mis. 4K di HP lawas). */
    private fun decoderOk(s: VideoStream): Boolean {
        val mime = when (family(s.codec)) {
            "AVC" -> "video/avc"
            "VP9" -> "video/x-vnd.on2.vp9"
            "AV1" -> "video/av01"
            "HEVC" -> "video/hevc"
            else -> return true
        }
        return try {
            val f = android.media.MediaFormat.createVideoFormat(
                mime, s.width.coerceAtLeast(16), s.height.coerceAtLeast(16),
            )
            MediaCodecList(MediaCodecList.REGULAR_CODECS).findDecoderForFormat(f) != null
        } catch (e: Exception) {
            true
        }
    }
}
