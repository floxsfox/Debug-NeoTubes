package app.neotube.data

import android.media.MediaCodecList
import android.net.Uri
import androidx.media3.common.MimeTypes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream

data class VideoItem(
    val url: String,
    val title: String,
    val uploader: String,
    val thumb: String?,
    val duration: Long,
    val views: Long,
    val uploaded: String?,
)

data class ChannelItem(val url: String, val name: String, val thumb: String?, val subs: Long, val desc: String?)
data class PlaylistItem(val url: String, val name: String, val thumb: String?, val uploader: String, val count: Long)
data class SearchPage(
    val videos: List<VideoItem> = emptyList(),
    val channels: List<ChannelItem> = emptyList(),
    val playlists: List<PlaylistItem> = emptyList(),
)

data class ChannelPage(
    val name: String, val url: String, val avatar: String?, val banner: String?,
    val subs: Long, val desc: String, val videos: List<VideoItem>,
)

data class PlaylistPage(val name: String, val uploader: String, val count: Long, val items: List<VideoItem>)
data class CommentItem(val author: String, val text: String, val likes: Int, val date: String?)

data class StreamChoice(
    val height: Int,
    val label: String,
    val tag: String,
    val url: String,
    val key: String,
    val bitrate: Long,
)

data class SubChoice(val label: String, val lang: String, val url: String, val mime: String)
data class Chapter(val startSec: Long, val title: String)

data class PlayInfo(
    val videoId: String,
    val url: String,
    val title: String,
    val uploader: String,
    val uploaderUrl: String?,
    val uploaderAvatar: String?,
    val views: Long,
    val likes: Long,
    val duration: Long,
    val description: String,
    val thumb: String?,
    val qualities: List<StreamChoice>,
    val audioUrl: String?,
    val audioKey: String?,
    val audioBitrate: Int,
    val hlsUrl: String?,
    val subs: List<SubChoice>,
    val chapters: List<Chapter>,
    val related: List<VideoItem>,
    val offline: Boolean = false,
) {
    fun toItem() = VideoItem(url, title, uploader, thumb, duration, views, null)
}

object Repo {
    private val yt get() = ServiceList.YouTube

    fun isVideoUrl(u: String) = Regex("(youtube\\.com/(watch|shorts|live)|youtu\\.be/)").containsMatchIn(u)

    suspend fun suggestions(q: String): List<String> = withContext(Dispatchers.IO) {
        yt.suggestionExtractor.suggestionList(q).take(8)
    }

    suspend fun search(query: String, filter: String = YoutubeSearchQueryHandlerFactory.VIDEOS): SearchPage =
        withContext(Dispatchers.IO) {
            val handler = yt.searchQHFactory.fromQuery(query, listOf(filter), "")
            val items = SearchInfo.getInfo(yt, handler).relatedItems
            SearchPage(
                videos = items.filterIsInstance<StreamInfoItem>().map { it.toItem() },
                channels = items.filterIsInstance<ChannelInfoItem>().map {
                    ChannelItem(it.url, it.name ?: "", it.thumbnails.best(), it.subscriberCount, it.description)
                },
                playlists = items.filterIsInstance<PlaylistInfoItem>().map {
                    PlaylistItem(it.url, it.name ?: "", it.thumbnails.best(), it.uploaderName ?: "", it.streamCount)
                },
            )
        }

    suspend fun channel(url: String): ChannelPage = withContext(Dispatchers.IO) {
        val info = ChannelInfo.getInfo(url)
        ChannelPage(
            name = info.name ?: "",
            url = url,
            avatar = info.avatars.best(),
            banner = info.banners.best(),
            subs = info.subscriberCount,
            desc = info.description ?: "",
            videos = channelVideosOf(info),
        )
    }

    suspend fun channelVideos(url: String, limit: Int): List<VideoItem> = withContext(Dispatchers.IO) {
        channelVideosOf(ChannelInfo.getInfo(url)).take(limit)
    }

    private fun channelVideosOf(info: ChannelInfo): List<VideoItem> {
        val tab = info.tabs.firstOrNull { it.contentFilters.contains(ChannelTabs.VIDEOS) } ?: return emptyList()
        val owner = info.name ?: ""
        return ChannelTabInfo.getInfo(yt, tab).relatedItems
            .filterIsInstance<StreamInfoItem>()
            .map { it.toItem() }
            .map { if (it.uploader.isBlank()) it.copy(uploader = owner) else it }
    }

    suspend fun playlist(url: String): PlaylistPage = withContext(Dispatchers.IO) {
        val i = PlaylistInfo.getInfo(url)
        PlaylistPage(
            i.name ?: "", i.uploaderName ?: "", i.streamCount,
            i.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toItem() },
        )
    }

    suspend fun comments(url: String): List<CommentItem> = withContext(Dispatchers.IO) {
        CommentsInfo.getInfo(url).relatedItems.map { c ->
            CommentItem(
                c.uploaderName ?: "",
                cleanHtml(c.commentText?.content ?: ""),
                c.likeCount,
                c.textualUploadDate,
            )
        }
    }

    suspend fun load(url: String): PlayInfo = withContext(Dispatchers.IO) {
        val info = StreamInfo.getInfo(url)
        val id = info.id

        // Video-only (adaptif) = jalur 1440p / 4K; digabung dengan audio terbaik saat diputar.
        val qualities = info.videoOnlyStreams
            .filter { it.isUrl && it.height > 0 && !it.content.isNullOrBlank() }
            .groupBy { it.height }
            .mapNotNull { (h, list) ->
                list.filter { decoderOk(it) }
                    .sortedWith(
                        compareBy<VideoStream> { rank(family(it.codec), h) }
                            .thenByDescending { it.bitrate },
                    )
                    .firstOrNull()
                    ?.let { s ->
                        StreamChoice(
                            height = h,
                            label = label(h, s.fps),
                            tag = if (h > 1080) family(s.codec) else "",
                            url = s.content,
                            key = "$id|v|$h|${s.fps}|${s.codec}|${s.bitrate}",
                            bitrate = s.bitrate.toLong(),
                        )
                    }
            }
            .sortedByDescending { it.height }

        val audio = info.audioStreams
            .filter { it.isUrl && !it.content.isNullOrBlank() }
            .maxByOrNull { (if (it.format?.suffix == "m4a") 1_000_000 else 0) + it.averageBitrate }

        val finalQualities = if (qualities.isNotEmpty()) qualities else {
            info.videoStreams
                .filter { it.isUrl && !it.content.isNullOrBlank() }
                .maxByOrNull { it.height }
                ?.let { s ->
                    listOf(
                        StreamChoice(
                            s.height, label(s.height, s.fps), "", s.content,
                            "$id|m|${s.height}|${s.codec}", s.bitrate.toLong(),
                        ),
                    )
                } ?: emptyList()
        }
        val muxedOnly = qualities.isEmpty()

        val desc = cleanHtml(info.description?.content ?: "")

        val subs = info.subtitles.mapNotNull { s ->
            val mime = when (s.format?.mimeType) {
                "text/vtt" -> MimeTypes.TEXT_VTT
                "application/ttml+xml" -> MimeTypes.APPLICATION_TTML
                "text/srt", "application/x-subrip" -> MimeTypes.APPLICATION_SUBRIP
                else -> null
            }
            if (mime == null || s.content.isNullOrBlank()) null else
                SubChoice(
                    label = (s.displayLanguageName ?: s.languageTag ?: "?") + if (s.isAutoGenerated) " (otomatis)" else "",
                    lang = s.languageTag ?: "und",
                    url = s.content,
                    mime = mime,
                )
        }.distinctBy { it.lang + it.label }
            .sortedWith(compareBy({ langRank(it.lang) }, { it.label }))

        PlayInfo(
            videoId = id,
            url = "https://www.youtube.com/watch?v=$id",
            title = info.name ?: "",
            uploader = info.uploaderName ?: "",
            uploaderUrl = info.uploaderUrl?.takeIf { it.isNotBlank() },
            uploaderAvatar = info.uploaderAvatars.best(),
            views = info.viewCount,
            likes = info.likeCount,
            duration = info.duration,
            description = desc,
            thumb = info.thumbnails.best(),
            qualities = finalQualities,
            audioUrl = if (muxedOnly) null else audio?.content,
            audioKey = if (muxedOnly || audio == null) null else "$id|a|${audio.format?.suffix}|${audio.averageBitrate}",
            audioBitrate = audio?.averageBitrate ?: 0,
            hlsUrl = info.hlsUrl?.takeIf { it.isNotBlank() },
            subs = subs,
            chapters = parseChapters(desc),
            related = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toItem() },
        )
    }

    fun offlineInfo(e: LibEntry): PlayInfo {
        fun fake(key: String) = "https://offline.neotube.invalid/" + Uri.encode(key)
        return PlayInfo(
            videoId = e.videoId, url = "https://www.youtube.com/watch?v=" + e.videoId,
            title = e.title, uploader = e.uploader, uploaderUrl = null, uploaderAvatar = null,
            views = -1, likes = -1, duration = e.duration, description = "", thumb = e.thumb,
            qualities = listOf(StreamChoice(e.height, e.label, "", fake(e.vKey), e.vKey, 0)),
            audioUrl = e.aKey?.let { fake(it) }, audioKey = e.aKey, audioBitrate = 0,
            hlsUrl = null, subs = emptyList(), chapters = emptyList(), related = emptyList(), offline = true,
        )
    }

    /** Bab video dari stempel waktu di deskripsi ("0:00 Intro"). Minimal 3 bab, mulai di awal video. */
    fun parseChapters(desc: String): List<Chapter> {
        val re = Regex("""^\W{0,3}((?:\d{1,2}:)?\d{1,2}:\d{2})\s*[-–—:|)\]]*\s*(.{1,90})$""")
        val out = ArrayList<Chapter>()
        for (line in desc.lineSequence()) {
            val m = re.find(line.trim()) ?: continue
            val p = m.groupValues[1].split(":").map { it.toLong() }
            val sec = if (p.size == 3) p[0] * 3600 + p[1] * 60 + p[2] else p[0] * 60 + p[1]
            if (out.isNotEmpty() && sec <= out.last().startSec) continue
            out.add(Chapter(sec, m.groupValues[2].trim()))
        }
        return if (out.size >= 3 && out.first().startSec <= 5) out else emptyList()
    }

    private fun cleanHtml(s: String): String = s
        .replace(Regex("(?i)<br\\s*/?>"), "\n")
        .replace(Regex("<[^>]*>"), "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">")
        .trim()

    private fun List<Image>?.best(): String? = this?.maxByOrNull { it.height }?.url

    private fun StreamInfoItem.toItem() = VideoItem(
        url = url,
        title = name ?: "",
        uploader = uploaderName ?: "",
        thumb = thumbnails.best(),
        duration = duration,
        views = viewCount,
        uploaded = textualUploadDate,
    )

    private fun langRank(l: String): Int = when {
        l.startsWith("id") -> 0
        l.startsWith("en") -> 1
        else -> 2
    }

    private fun family(codec: String?): String = when {
        codec == null -> "?"
        codec.startsWith("avc") -> "AVC"
        codec.startsWith("vp9") || codec.startsWith("vp09") -> "VP9"
        codec.startsWith("av01") -> "AV1"
        codec.startsWith("hev") || codec.startsWith("hvc") -> "HEVC"
        else -> "?"
    }

    // <=1080p: utamakan AVC (decoder hardware ada di mana-mana). >1080p: VP9 dulu, lalu AV1.
    private fun rank(f: String, h: Int): Int =
        if (h <= 1080) when (f) { "AVC" -> 0; "VP9" -> 1; "AV1" -> 2; else -> 3 }
        else when (f) { "VP9" -> 0; "AV1" -> 1; "HEVC" -> 2; "AVC" -> 3; else -> 4 }

    private fun label(h: Int, fps: Int): String {
        val base = when {
            h >= 4320 -> "8K"
            h >= 2160 -> "4K"
            else -> "${h}p"
        }
        return if (fps > 30) "$base$fps" else base
    }

    /** Sembunyikan kualitas yang tidak bisa di-decode perangkat (mis. 4K di HP lawas). */
    private fun decoderOk(s: VideoStream): Boolean {
        val mime = when (family(s.codec)) {
            "AVC" -> "video/avc"
            "VP9" -> "video/x-vnd.on2.vp9"
            "AV1" -> "video/av01"
            "HEVC" -> "video/hevc"
            else -> return true
        }
        return try {
            val f = android.media.MediaFormat.createVideoFormat(
                mime, s.width.coerceAtLeast(16), s.height.coerceAtLeast(16),
            )
            MediaCodecList(MediaCodecList.REGULAR_CODECS).findDecoderForFormat(f) != null
        } catch (e: Exception) {
            true
        }
    }
}
