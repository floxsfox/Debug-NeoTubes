package app.neotube.data

import android.app.Application
import app.neotube.R
import android.app.Notification
import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.offline.Download as Dl
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.Scheduler
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import org.json.JSONArray
import org.json.JSONObject

private const val UA_WEB = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
private const val UA_ANDROID = "com.google.android.youtube/19.44.38 (Linux; U; Android 14) gzip"
private const val UA_IOS = "com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)"

/**
 * Resolver untuk URL googlevideo: tambahkan parameter `range` (bebas throttling / 403 di tengah video)
 * dan pakai User-Agent yang cocok dengan klien yang membuat URL (parameter `c`).
 */
private val GoogleVideoResolver = ResolvingDataSource.Resolver { spec ->
    val uri = spec.uri
    if (uri.host?.endsWith("googlevideo.com") != true) return@Resolver spec

    var out = spec
    val clen = uri.getQueryParameter("clen")?.toLongOrNull()
    if (clen != null && uri.getQueryParameter("range") == null) {
        // Server membalas 200 + potongan byte. Jangan kirim header Range lagi (position=0, length unset),
        // kalau tidak DefaultHttpDataSource membuang `position` byte ekstra -> data salah / parser error.
        val start = spec.position
        val end = if (spec.length != C.LENGTH_UNSET.toLong()) start + spec.length - 1 else clen - 1
        out = spec.buildUpon()
            .setUri(uri.buildUpon().appendQueryParameter("range", "$start-$end").build())
            .setPosition(0)
            .setLength(C.LENGTH_UNSET.toLong())
            .build()
    }
    val ua = when (uri.getQueryParameter("c")) {
        "IOS" -> UA_IOS
        "ANDROID" -> UA_ANDROID
        else -> UA_WEB
    }
    out.withAdditionalHeaders(mapOf("User-Agent" to ua))
}

object ServiceLocator {
    const val CHANNEL_ID = "neotube_dl"

    lateinit var app: Application
        private set

    val okHttp: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /** Status semua unduhan (id = cache key). Diperbarui listener + polling progres. */
    val downloads = MutableStateFlow<Map<String, Dl>>(emptyMap())

    private val dbProvider by lazy { StandaloneDatabaseProvider(app) }

    /** Satu-satunya cache: isinya hanya video yang diunduh pengguna (tanpa eviction). */
    val cache: SimpleCache by lazy {
        val dir = File(app.getExternalFilesDir(null) ?: app.filesDir, "media_cache")
        SimpleCache(dir, NoOpCacheEvictor(), dbProvider)
    }

    val httpFactory: DataSource.Factory by lazy {
        ResolvingDataSource.Factory(
            DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15_000)
                .setReadTimeoutMs(20_000),
            GoogleVideoResolver,
        )
    }

    /** Pemutaran: baca dari cache unduhan kalau ada, kalau tidak streaming (tanpa menulis ke cache). */
    val playbackFactory: DataSource.Factory by lazy {
        CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(httpFactory)
            .setCacheWriteDataSinkFactory(null)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    val downloadManager: DownloadManager by lazy {
        DownloadManager(app, dbProvider, cache, httpFactory, Executors.newFixedThreadPool(3)).also { dm ->
            dm.maxParallelDownloads = 2
            dm.addListener(object : DownloadManager.Listener {
                override fun onDownloadChanged(downloadManager: DownloadManager, download: Dl, finalException: Exception?) {
                    downloads.update { it + (download.request.id to download) }
                }

                override fun onDownloadRemoved(downloadManager: DownloadManager, download: Dl) {
                    downloads.update { it - download.request.id }
                }
            })
        }
    }

    val notificationHelper: DownloadNotificationHelper by lazy { DownloadNotificationHelper(app, CHANNEL_ID) }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun init(application: Application) {
        app = application
        Library.load()
        Settings.load()
        val dm = downloadManager // dibuat di main thread

        thread(name = "neotube-dl-index") {
            try {
                dm.downloadIndex.getDownloads().use { c ->
                    val m = HashMap<String, Dl>()
                    while (c.moveToNext()) {
                        val d = c.download
                        m[d.request.id] = d
                    }
                    downloads.update { m + it }
                }
            } catch (e: Exception) {
            }
        }
        scope.launch {
            while (true) {
                delay(1000)
                val cur = dm.currentDownloads
                if (cur.isNotEmpty()) downloads.update { m -> m + cur.associateBy { it.request.id } }
            }
        }
    }
}

class NeoDownloadService : DownloadService(
    1001,
    DownloadService.DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
    ServiceLocator.CHANNEL_ID,
    R.string.dl_channel,
    0,
) {
    override fun getDownloadManager(): DownloadManager = ServiceLocator.downloadManager

    override fun getScheduler(): Scheduler? = null

    override fun getForegroundNotification(downloads: MutableList<Dl>, notMetRequirements: Int): Notification =
        ServiceLocator.notificationHelper.buildProgressNotification(
            this, android.R.drawable.stat_sys_download, null, null, downloads, notMetRequirements,
        )
}

data class LibEntry(
    val videoId: String,
    val title: String,
    val uploader: String,
    val thumb: String?,
    val duration: Long,
    val height: Int,
    val label: String,
    val vKey: String,
    val aKey: String?,
    val addedAt: Long,
)

/** Daftar unduhan (metadata) disimpan di SharedPreferences; byte videonya ada di cache Media3. */
object Library {
    private val prefs by lazy { ServiceLocator.app.getSharedPreferences("neotube_lib", Context.MODE_PRIVATE) }
    private val _entries = MutableStateFlow<List<LibEntry>>(emptyList())
    val entries: StateFlow<List<LibEntry>> = _entries

    fun load() {
        try {
            val arr = JSONArray(prefs.getString("entries", "[]"))
            _entries.value = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                LibEntry(
                    videoId = o.getString("videoId"),
                    title = o.getString("title"),
                    uploader = o.optString("uploader", ""),
                    thumb = o.optString("thumb", "").ifBlank { null },
                    duration = o.optLong("duration", 0),
                    height = o.optInt("height", 0),
                    label = o.optString("label", ""),
                    vKey = o.getString("vKey"),
                    aKey = o.optString("aKey", "").ifBlank { null },
                    addedAt = o.optLong("addedAt", 0),
                )
            }
        } catch (e: Exception) {
            _entries.value = emptyList()
        }
    }

    private fun save() {
        val arr = JSONArray()
        _entries.value.forEach { e ->
            arr.put(
                JSONObject()
                    .put("videoId", e.videoId).put("title", e.title).put("uploader", e.uploader)
                    .put("thumb", e.thumb ?: "").put("duration", e.duration).put("height", e.height)
                    .put("label", e.label).put("vKey", e.vKey).put("aKey", e.aKey ?: "")
                    .put("addedAt", e.addedAt),
            )
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }

    fun startDownload(ctx: Context, info: PlayInfo, q: StreamChoice) {
        val v = DownloadRequest.Builder(q.key, Uri.parse(q.url)).setCustomCacheKey(q.key).build()
        DownloadService.sendAddDownload(ctx, NeoDownloadService::class.java, v, false)
        if (info.audioUrl != null && info.audioKey != null) {
            val a = DownloadRequest.Builder(info.audioKey, Uri.parse(info.audioUrl))
                .setCustomCacheKey(info.audioKey).build()
            DownloadService.sendAddDownload(ctx, NeoDownloadService::class.java, a, false)
        }
        val entry = LibEntry(
            info.videoId, info.title, info.uploader, info.thumb, info.duration,
            q.height, q.label, q.key, info.audioKey, System.currentTimeMillis(),
        )
        _entries.value = listOf(entry) + _entries.value.filter { it.vKey != entry.vKey }
        save()
    }

    fun remove(ctx: Context, e: LibEntry) {
        DownloadService.sendRemoveDownload(ctx, NeoDownloadService::class.java, e.vKey, false)
        val audioShared = _entries.value.any { it !== e && it.aKey == e.aKey }
        if (e.aKey != null && !audioShared) {
            DownloadService.sendRemoveDownload(ctx, NeoDownloadService::class.java, e.aKey, false)
        }
        _entries.value = _entries.value.filter { it !== e }
        save()
    }
}
