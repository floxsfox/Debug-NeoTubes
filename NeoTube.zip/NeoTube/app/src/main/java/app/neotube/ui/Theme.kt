package app.neotube.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Tema gelap: dasar hampir hitam, aksen violet -> cyan, kaca tipis di atas aurora redup.
val Ink = Color(0xFF07080C)
val Violet = Color(0xFF7C5CFF)
val Cyan = Color(0xFF22D3EE)
val Rose = Color(0xFFFF4D8D)
val Mint = Color(0xFF34D399)
val TextDim = Color(0xFFA6A9B8)

val GlassFill = listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.04f))
val GlassDark = listOf(Color(0xF2191A24), Color(0xF20F1017))
val AccentFill = listOf(Violet.copy(alpha = 0.95f), Cyan.copy(alpha = 0.85f))
val MintFill = listOf(Mint.copy(alpha = 0.40f), Mint.copy(alpha = 0.18f))
val DangerFill = listOf(Rose.copy(alpha = 0.45f), Rose.copy(alpha = 0.22f))

private val GlassEdge = Brush.linearGradient(
    listOf(Color.White.copy(alpha = 0.42f), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.20f)),
)

val TitleBrush = Brush.linearGradient(listOf(Color.White, Cyan, Violet))

@Composable
fun NeoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            secondary = Cyan,
            background = Ink,
            surface = Ink,
            onBackground = Color.White,
            onSurface = Color.White,
        ),
        content = content,
    )
}

/** Latar "aurora" redup yang bergerak pelan — bahan yang "ditembus" kaca. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0f, infiniteRepeatable(tween(24000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Canvas(modifier.fillMaxSize().background(Ink)) {
        fun blob(c: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c.copy(alpha = alpha), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = r,
                ),
                radius = r,
                center = Offset(cx, cy),
            )
        }
        val w = size.width
        val h = size.height
        blob(Violet, w * (0.10f + 0.55f * a), h * (0.08f + 0.10f * b), w * 0.95f, 0.38f)
        blob(Cyan, w * (0.95f - 0.55f * b), h * (0.45f + 0.14f * a), w * 0.80f, 0.20f)
        blob(Rose, w * (0.15f + 0.35f * b), h * (0.90f - 0.12f * a), w * 0.85f, 0.18f)
    }
}

/** Permukaan kaca: gradasi tembus pandang, tepi berkilau, sorot cahaya, efek pegas saat ditekan. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    fill: List<Color> = GlassFill,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 450f),
        label = "press",
    )
    val base = modifier
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clip(shape)
        .background(Brush.verticalGradient(fill))
        .border(1.dp, GlassEdge, shape)
        .drawWithContent {
            drawContent()
            drawRect(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(size.width * 0.10f, 0f),
                    radius = size.width * 0.7f,
                ),
            )
        }
    val m = if (onClick != null) {
        base.clickable(interactionSource = source, indication = null, onClick = onClick)
    } else base
    Box(m, content = content)
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    fill: List<Color> = GlassDark,
    tint: Color = Color.White,
) {
    GlassCard(modifier.size(size), CircleShape, fill, onClick) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.align(Alignment.Center).size(size * 0.5f))
    }
}
