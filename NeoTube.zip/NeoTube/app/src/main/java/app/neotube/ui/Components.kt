package app.neotube.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.WatchLater
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.neotube.data.ChannelItem
import app.neotube.data.Local
import app.neotube.data.Playback
import app.neotube.data.PlaylistItem
import app.neotube.data.Sub
import app.neotube.data.VideoItem
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

/** Status UI global: sheet menu, dialog playlist, toast. */
object UiState {
    var menuVideo by mutableStateOf<VideoItem?>(null)
    var pickVideo by mutableStateOf<VideoItem?>(null)
    var newPlaylistOpen by mutableStateOf(false)
    var newPlaylistFirst by mutableStateOf<VideoItem?>(null)
    var toastText by mutableStateOf<String?>(null)
    var toastTick by mutableIntStateOf(0)

    fun toast(t: String) {
        toastText = t
        toastTick++
    }
}

// ---------------- util tindakan ----------------

fun shareText(ctx: Context, text: String) {
    ctx.startActivity(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            },
            null,
        ),
    )
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("NeoTube", text))
    UiState.toast("Tautan disalin")
}

fun openInYouTube(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube"))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e2: Exception) {
        }
    }
}

// ---------------- elemen dasar ----------------

@Composable
fun ScreenHeader(title: String, modifier: Modifier = Modifier, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            Modifier.weight(1f),
            style = TextStyle(brush = TitleBrush, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp),
        )
        trailing()
    }
}

@Composable
fun BackHeader(title: String, onBack: () -> Unit, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        GlassIconButton(Icons.Rounded.ArrowBack, onBack, size = 42.dp)
        Text(title, Modifier.weight(1f), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        trailing()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(horizontal = 20.dp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    GlassCard(modifier, RoundedCornerShape(50), if (selected) AccentFill else GlassFill, onClick) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp))
            Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier) {
    GlassCard(modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(26.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(36.dp))
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(text, color = TextDim, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
fun Avatar(url: String?, size: Dp, modifier: Modifier = Modifier) {
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.size(size).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)),
    )
}

@Composable
fun Thumb(url: String?, duration: Long, modifier: Modifier, progress: Float? = null) {
    Box(
        modifier.aspectRatio(16f / 9f).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.06f)),
    ) {
        AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (duration > 0) {
            Box(
                Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.7f)),
            ) {
                Text(
                    fmtDur(duration),
                    Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                )
            }
        }
        if (progress != null && progress > 0f) {
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = 0.25f)))
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(progress.coerceIn(0f, 1f)).height(3.dp).background(Rose))
        }
    }
}

private fun metaOf(v: VideoItem, withUploader: Boolean): String = listOf(
    if (withUploader) v.uploader else "",
    if (v.views >= 0) fmtCount(v.views) + " x ditonton" else "",
    v.uploaded ?: "",
).filter { it.isNotBlank() }.joinToString(" • ")

@Composable
fun VideoCard(item: VideoItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    GlassCard(modifier.fillMaxWidth(), RoundedCornerShape(26.dp), onClick = onClick) {
        Column(Modifier.padding(8.dp)) {
            Thumb(item.thumb, item.duration, Modifier.fillMaxWidth())
            Row(Modifier.padding(start = 8.dp, top = 10.dp, bottom = 4.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(item.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 21.sp)
                    Text(metaOf(item, true), color = TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(
                    Icons.Rounded.MoreVert, "Menu", tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.clip(CircleShape).clickable { UiState.menuVideo = item }.padding(6.dp),
                )
            }
        }
    }
}

@Composable
fun VideoRow(
    item: VideoItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    progress: Float? = null,
    trailing: @Composable (() -> Unit)? = null,
) {
    GlassCard(modifier.fillMaxWidth(), RoundedCornerShape(20.dp), onClick = onClick) {
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Thumb(item.thumb, item.duration, Modifier.width(150.dp), progress)
            Column(Modifier.weight(1f).padding(top = 2.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 19.sp)
                Text(item.uploader, color = TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val m = metaOf(item, false)
                if (m.isNotBlank()) Text(m, color = TextDim.copy(alpha = 0.8f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (trailing != null) trailing() else Icon(
                Icons.Rounded.MoreVert, "Menu", tint = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.clip(CircleShape).clickable { UiState.menuVideo = item }.padding(4.dp),
            )
        }
    }
}

@Composable
fun ChannelRow(c: ChannelItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val subs by Local.subs.items.collectAsStateWithLifecycle()
    val isSub = subs.any { it.url == c.url }
    GlassCard(modifier.fillMaxWidth(), RoundedCornerShape(24.dp), onClick = onClick) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.thumb, 56.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(c.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (c.subs >= 0) Text(fmtCount(c.subs) + " pelanggan", color = TextDim, fontSize = 13.sp)
            }
            SubscribeButton(isSub) {
                val now = Local.subs.toggle(Sub(c.url, c.name, c.thumb))
                UiState.toast(if (now) "Berlangganan ${c.name}" else "Berhenti berlangganan")
            }
        }
    }
}

@Composable
fun SubscribeButton(subscribed: Boolean, onClick: () -> Unit) {
    GlassCard(Modifier, RoundedCornerShape(50), if (subscribed) GlassFill else listOf(Color.White, Color(0xFFE6E6F0)), onClick) {
        Text(
            if (subscribed) "Berlangganan" else "Langganan",
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            color = if (subscribed) Color.White else Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
fun PlaylistRow(p: PlaylistItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    GlassCard(modifier.fillMaxWidth(), RoundedCornerShape(20.dp), onClick = onClick) {
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Thumb(p.thumb, 0, Modifier.width(150.dp))
            Column(Modifier.weight(1f).padding(top = 2.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(p.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(p.uploader, color = TextDim, fontSize = 12.sp, maxLines = 1)
                if (p.count >= 0) Text("${p.count} video", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun GlassTextField(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier, onDone: () -> Unit = {}) {
    GlassCard(modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
        Box(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            if (value.isEmpty()) Text(hint, color = Color.White.copy(alpha = 0.4f), fontSize = 16.sp)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Cyan),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onDone() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ---------------- sheet kaca ----------------

@Composable
fun GlassSheet(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    BackHandler(enabled = visible) { onDismiss() }
    val src = remember { MutableInteractionSource() }
    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f))
                .clickable(interactionSource = src, indication = null) { onDismiss() },
        )
    }
    AnimatedVisibility(visible, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            GlassCard(
                Modifier.fillMaxWidth().pointerInput(Unit) { detectTapGestures { } },
                RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
                GlassDark,
            ) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .heightIn(max = 560.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        Modifier.align(Alignment.CenterHorizontally).width(40.dp).height(4.dp)
                            .clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.3f)),
                    )
                    content()
                }
            }
        }
    }
}

@Composable
fun SheetAction(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.85f))
        Text(text, color = Color.White, fontSize = 16.sp)
    }
}

@Composable
fun VideoMenuSheet() {
    val ctx = LocalContext.current
    val v = UiState.menuVideo
    val later by Local.watchLater.items.collectAsStateWithLifecycle()
    val liked by Local.liked.items.collectAsStateWithLifecycle()
    GlassSheet(v != null, { UiState.menuVideo = null }) {
        if (v != null) {
            Text(v.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            SheetAction(Icons.Rounded.PlaylistPlay, "Putar berikutnya") {
                Playback.enqueue(v); UiState.toast("Ditambahkan ke antrean"); UiState.menuVideo = null
            }
            val inLater = later.any { it.url == v.url }
            SheetAction(Icons.Rounded.WatchLater, if (inLater) "Hapus dari Tonton nanti" else "Simpan ke Tonton nanti") {
                val now = Local.watchLater.toggle(v)
                UiState.toast(if (now) "Disimpan ke Tonton nanti" else "Dihapus dari Tonton nanti"); UiState.menuVideo = null
            }
            val isLiked = liked.any { it.url == v.url }
            SheetAction(if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (isLiked) "Batal suka" else "Suka") {
                val now = Local.liked.toggle(v)
                UiState.toast(if (now) "Ditambahkan ke Disukai" else "Dihapus dari Disukai"); UiState.menuVideo = null
            }
            SheetAction(Icons.Rounded.PlaylistAdd, "Tambah ke playlist") {
                UiState.pickVideo = v; UiState.menuVideo = null
            }
            SheetAction(Icons.Rounded.Share, "Bagikan") { shareText(ctx, v.url); UiState.menuVideo = null }
            SheetAction(Icons.Rounded.ContentCopy, "Salin tautan") { copyText(ctx, v.url); UiState.menuVideo = null }
            SheetAction(Icons.Rounded.OpenInNew, "Buka di aplikasi YouTube") { openInYouTube(ctx, v.url); UiState.menuVideo = null }
        }
    }
}

@Composable
fun PlaylistPickerSheet() {
    val v = UiState.pickVideo
    val lists by Local.playlists.items.collectAsStateWithLifecycle()
    GlassSheet(v != null, { UiState.pickVideo = null }) {
        if (v != null) {
            Text("Simpan ke playlist", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            SheetAction(Icons.Rounded.PlaylistAdd, "Playlist baru") {
                UiState.newPlaylistFirst = v; UiState.newPlaylistOpen = true; UiState.pickVideo = null
            }
            lists.forEach { p ->
                SheetAction(Icons.Rounded.PlaylistPlay, p.name + "  (" + p.items.size + ")") {
                    Local.playlists.add(p.id, v); UiState.toast("Disimpan ke ${p.name}"); UiState.pickVideo = null
                }
            }
        }
    }
}

@Composable
fun NewPlaylistSheet() {
    GlassSheet(UiState.newPlaylistOpen, { UiState.newPlaylistOpen = false }) {
        var name by remember { mutableStateOf("") }
        fun create() {
            if (name.isBlank()) return
            Local.playlists.create(name, UiState.newPlaylistFirst)
            UiState.toast("Playlist dibuat")
            UiState.newPlaylistFirst = null
            UiState.newPlaylistOpen = false
        }
        Text("Playlist baru", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        GlassTextField(name, { name = it }, "Nama playlist", onDone = { create() })
        GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(50), AccentFill, { create() }) {
            Text("Buat", Modifier.fillMaxWidth().padding(vertical = 13.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
fun ToastHost(modifier: Modifier = Modifier) {
    val t = UiState.toastText
    LaunchedEffect(UiState.toastTick) {
        if (UiState.toastText != null) {
            delay(2200)
            UiState.toastText = null
        }
    }
    AnimatedVisibility(t != null, modifier, enter = fadeIn() + slideInVertically { it / 2 }, exit = fadeOut()) {
        GlassCard(Modifier, RoundedCornerShape(50), GlassDark) {
            Text(t ?: "", Modifier.padding(horizontal = 20.dp, vertical = 12.dp), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
