package app.neotube.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.neotube.data.Playback
import coil.compose.AsyncImage

sealed interface Screen {
    data class Channel(val url: String) : Screen
    data class Playlist(val url: String) : Screen
    data class UserPlaylist(val id: String) : Screen
    data object Prefs : Screen
}

object Nav {
    var tab by mutableIntStateOf(0)
    val stack = mutableStateListOf<Screen>()
    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
}

@Composable
fun topPad(): Dp = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp

/** Ruang kosong di bawah daftar supaya tidak tertutup mini player + navigasi. */
@Composable
fun bottomPad(): Dp =
    WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + if (Playback.active) 170.dp else 110.dp

@Composable
fun NeoTubeApp() {
    val ctx = LocalContext.current
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    BackHandler(enabled = Nav.stack.isNotEmpty()) { Nav.pop() }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        when (Nav.tab) {
            0 -> HomeScreen()
            1 -> SubsScreen()
            else -> LibraryScreen()
        }

        val top = Nav.stack.lastOrNull()
        if (top != null) {
            Box(Modifier.fillMaxSize()) {
                AuroraBackground()
                key(top) {
                    when (top) {
                        is Screen.Channel -> ChannelScreen(top.url)
                        is Screen.Playlist -> PlaylistScreen(top.url)
                        is Screen.UserPlaylist -> UserPlaylistScreen(top.id)
                        Screen.Prefs -> SettingsScreen()
                    }
                }
            }
        }

        // Rak bawah: pudar ke gelap + mini player + navigasi.
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF207080C), Color(0xFF07080C))))
                .navigationBarsPadding()
                .padding(top = 28.dp, bottom = 10.dp),
        ) {
            if (Playback.active) MiniPlayer()
            GlassNav(Nav.tab) { Nav.stack.clear(); Nav.tab = it }
        }

        AnimatedVisibility(
            visible = Playback.active && Playback.expanded,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) { PlayerScreen() }

        VideoMenuSheet()
        PlaylistPickerSheet()
        NewPlaylistSheet()
        ToastHost(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 12.dp))
    }
}

@Composable
private fun GlassNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        "Beranda" to Icons.Rounded.Home,
        "Langganan" to Icons.Rounded.Subscriptions,
        "Pustaka" to Icons.Rounded.VideoLibrary,
    )
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        GlassCard(Modifier, RoundedCornerShape(34.dp), GlassDark) {
            Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items.forEachIndexed { i, (label, icon) ->
                    val sel = i == selected
                    val glow by animateFloatAsState(if (sel) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = 400f), label = "nav")
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(28.dp))
                            .background(Brush.linearGradient(listOf(Violet.copy(alpha = 0.9f * glow), Cyan.copy(alpha = 0.75f * glow))))
                            .clickable { onSelect(i) }
                            .padding(horizontal = if (sel) 20.dp else 16.dp, vertical = 11.dp)
                            .animateContentSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(icon, label, tint = Color.White.copy(alpha = 0.55f + 0.45f * glow), modifier = Modifier.size(22.dp))
                        if (sel) Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer() {
    val i = Playback.info
    val frac = if (Playback.durationMs > 0) (Playback.positionMs.toFloat() / Playback.durationMs).coerceIn(0f, 1f) else 0f
    GlassCard(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(bottom = 10.dp),
        RoundedCornerShape(24.dp), GlassDark,
        onClick = { Playback.expanded = true },
    ) {
        Column {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.width(88.dp).height(50.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.06f))) {
                    AsyncImage(model = i?.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        i?.title ?: if (Playback.error != null) "Gagal memutar" else "Memuat…",
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text(i?.uploader ?: "", color = TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(
                    if (Playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Putar/jeda", tint = Color.White,
                    modifier = Modifier.size(40.dp).clip(CircleShape).clickable { Playback.togglePlay() }.padding(7.dp),
                )
                Icon(
                    Icons.Rounded.Close, "Tutup", tint = Color.White.copy(alpha = 0.75f),
                    modifier = Modifier.size(36.dp).clip(CircleShape).clickable { Playback.close() }.padding(8.dp),
                )
            }
            Box(Modifier.fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = 0.12f))) {
                Box(Modifier.fillMaxWidth(frac).height(3.dp).background(Brush.horizontalGradient(listOf(Violet, Cyan))))
            }
        }
    }
}
