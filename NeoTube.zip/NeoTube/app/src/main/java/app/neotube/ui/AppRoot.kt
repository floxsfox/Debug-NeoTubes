package app.neotube.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.exoplayer.offline.Download as Dl
import app.neotube.data.LibEntry
import app.neotube.data.Library
import app.neotube.data.Repo
import app.neotube.data.ServiceLocator
import app.neotube.data.VideoItem
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException

sealed interface PlayTarget {
    data class Online(val url: String) : PlayTarget
    data class Offline(val entry: LibEntry) : PlayTarget
}

@Composable
fun NeoTubeApp() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var target by remember { mutableStateOf<PlayTarget?>(null) }
    var playerVisible by remember { mutableStateOf(false) }

    fun open(t: PlayTarget) {
        target = t
        playerVisible = true
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        when (tab) {
            0 -> HomeScreen(onPlay = { open(PlayTarget.Online(it)) })
            else -> LibraryScreen(onPlay = { open(PlayTarget.Offline(it)) })
        }
        GlassNav(
            selected = tab,
            onSelect = { tab = it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 12.dp),
        )
        AnimatedVisibility(
            visible = playerVisible,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            target?.let { t ->
                androidx.compose.runtime.key(t) {
                    PlayerScreen(
                        target = t,
                        onClose = { playerVisible = false },
                        onOpen = { url -> open(PlayTarget.Online(url)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassNav(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf("Beranda" to Icons.Rounded.Home, "Unduhan" to Icons.Rounded.Download)
    GlassCard(modifier, shape = RoundedCornerShape(36.dp), fill = GlassDark) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEachIndexed { i, (label, icon) ->
                val sel = i == selected
                val glow by animateFloatAsState(if (sel) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 350f), label = "navglow")
                Box(
                    Modifier
                        .clip(RoundedCornerShape(30.dp))
                        .background(Brush.linearGradient(listOf(Violet.copy(alpha = 0.9f * glow), Cyan.copy(alpha = 0.75f * glow))))
                        .clickable { onSelect(i) }
                        .padding(horizontal = 22.dp, vertical = 11.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(icon, null, tint = Color.White.copy(alpha = 0.6f + 0.4f * glow), modifier = Modifier.size(22.dp))
                        Text(label, color = Color.White.copy(alpha = 0.6f + 0.4f * glow), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun topInset() = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

@Composable
private fun bottomInset() = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

private val Chips = listOf(
    "Untuk Kamu" to "trending indonesia",
    "Musik" to "lagu terbaru",
    "Game" to "gameplay terbaru",
    "Film" to "trailer film terbaru",
    "Berita" to "berita terkini",
    "Teknologi" to "review gadget terbaru",
    "Olahraga" to "highlight olahraga",
)

@Composable
fun HomeScreen(onPlay: (String) -> Unit) {
    val focus = LocalFocusManager.current
    var chip by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var term by rememberSaveable { mutableStateOf(Chips[0].second) }
    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }

    LaunchedEffect(term, retry) {
        loading = true
        error = null
        try {
            videos = Repo.search(term)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            videos = emptyList()
            error = e.message ?: e.toString()
        }
        loading = false
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = topInset() + 12.dp, bottom = bottomInset() + 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                "NeoTube",
                modifier = Modifier.padding(horizontal = 20.dp),
                style = TextStyle(
                    brush = Brush.linearGradient(listOf(Color.White, Cyan, Violet)),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-1).sp,
                ),
            )
        }
        item {
            GlassSearchField(
                value = query,
                onChange = { query = it },
                onSearch = {
                    if (query.isNotBlank()) {
                        chip = -1
                        term = query.trim()
                        focus.clearFocus()
                    }
                },
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
            ) {
                items(Chips.size) { i ->
                    val sel = i == chip
                    GlassCard(
                        shape = RoundedCornerShape(50),
                        fill = if (sel) AccentFill else GlassFill,
                        onClick = {
                            chip = i
                            query = ""
                            term = Chips[i].second
                        },
                    ) {
                        Text(
                            Chips[i].first,
                            Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
        }
        if (loading) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Cyan, strokeWidth = 3.dp)
                }
            }
        }
        if (error != null) {
            item {
                GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), onClick = { retry++ }) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Gagal memuat video", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(error ?: "", color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp, maxLines = 6, overflow = TextOverflow.Ellipsis)
                        Text("Ketuk untuk coba lagi", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        items(videos) { v ->
            VideoCard(v, onClick = { onPlay(v.url) }, modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}

@Composable
private fun GlassSearchField(value: String, onChange: (String) -> Unit, onSearch: () -> Unit, modifier: Modifier = Modifier) {
    GlassCard(modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, null, tint = Color.White.copy(alpha = 0.7f))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (value.isEmpty()) Text("Cari video", color = Color.White.copy(alpha = 0.45f), fontSize = 16.sp)
                BasicTextField(
                    value = value,
                    onValueChange = onChange,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Cyan),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (value.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Close, "Hapus",
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.clickable { onChange("") },
                )
            }
        }
    }
}

@Composable
fun VideoCard(item: VideoItem, onClick: () -> Unit, modifier: Modifier = Modifier, compact: Boolean = false) {
    val meta = listOf(
        if (compact) "" else item.uploader,
        if (item.views >= 0) fmtCount(item.views) + " x ditonton" else "",
        item.uploaded ?: "",
    ).filter { it.isNotBlank() }.joinToString(" • ")

    if (compact) {
        GlassCard(modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), onClick = onClick) {
            Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Thumb(item.thumb, item.duration, Modifier.width(150.dp))
                Column(Modifier.weight(1f).padding(vertical = 2.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(item.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.uploader, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(meta, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    } else {
        GlassCard(modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), onClick = onClick) {
            Column(Modifier.padding(8.dp)) {
                Thumb(item.thumb, item.duration, Modifier.fillMaxWidth())
                Column(Modifier.padding(horizontal = 8.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(item.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(meta, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun Thumb(url: String?, duration: Long, modifier: Modifier) {
    Box(
        modifier
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.06f)),
    ) {
        AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (duration > 0) {
            GlassCard(
                Modifier.align(Alignment.BottomEnd).padding(8.dp),
                shape = RoundedCornerShape(10.dp),
                fill = listOf(Color.Black.copy(alpha = 0.6f), Color.Black.copy(alpha = 0.6f)),
            ) {
                Text(
                    fmtDur(duration),
                    Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
fun LibraryScreen(onPlay: (LibEntry) -> Unit) {
    val ctx = LocalContext.current
    val entries by Library.entries.collectAsStateWithLifecycle()
    val dls by ServiceLocator.downloads.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = topInset() + 12.dp, bottom = bottomInset() + 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "Unduhan",
                    style = TextStyle(
                        brush = Brush.linearGradient(listOf(Color.White, Cyan, Violet)),
                        fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp,
                    ),
                )
                Text(
                    "Terpakai ${fmtBytes(ServiceLocator.cache.cacheSpace)} di perangkat",
                    color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp,
                )
            }
        }
        if (entries.isEmpty()) {
            item {
                GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Belum ada unduhan", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            "Buka video, pilih kualitas, lalu ketuk Unduh. Video tersimpan di perangkat dan bisa diputar tanpa internet.",
                            color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp,
                        )
                    }
                }
            }
        }
        items(entries) { e ->
            val parts = listOfNotNull(dls[e.vKey], e.aKey?.let { dls[it] })
            val expected = if (e.aKey != null) 2 else 1
            val done = parts.size == expected && parts.all { it.state == Dl.STATE_COMPLETED }
            val failed = parts.any { it.state == Dl.STATE_FAILED }
            val pct: Float = if (parts.isEmpty()) 0f else parts.map { it.percentDownloaded.coerceAtLeast(0f) }.average().toFloat()
            val bytes = parts.sumOf { it.bytesDownloaded }

            GlassCard(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                shape = RoundedCornerShape(24.dp),
                onClick = if (done) ({ onPlay(e) }) else null,
            ) {
                Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Thumb(e.thumb, e.duration, Modifier.width(130.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(e.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        val status = when {
                            done -> "${e.label} • ${fmtBytes(bytes)} • siap diputar offline"
                            failed -> "Gagal — hapus lalu unduh ulang"
                            parts.isEmpty() -> "Menunggu antrean"
                            else -> "Mengunduh ${pct.toInt()}% • ${fmtBytes(bytes)}"
                        }
                        Text(status, color = if (failed) Rose else Color.White.copy(alpha = 0.65f), fontSize = 12.sp, maxLines = 2)
                        if (!done && !failed) {
                            LinearProgressIndicator(
                                progress = { (pct / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth(),
                                color = Cyan,
                                trackColor = Color.White.copy(alpha = 0.15f),
                            )
                        }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (done) GlassIconButton(Icons.Rounded.PlayArrow, { onPlay(e) }, size = 40.dp, fill = AccentFill)
                        GlassIconButton(Icons.Rounded.Delete, { Library.remove(ctx, e) }, size = 40.dp)
                    }
                }
            }
        }
    }
}
