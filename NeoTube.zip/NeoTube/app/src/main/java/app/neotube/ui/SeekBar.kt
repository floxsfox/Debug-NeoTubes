package app.neotube.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.neotube.data.Chapter

fun chapterAt(chapters: List<Chapter>, posSec: Long): Chapter? = chapters.lastOrNull { it.startSec <= posSec }

/**
 * Seekbar custom: trek tipis yang menebal saat disentuh, area buffer, gradasi violet→cyan,
 * celah pemisah bab, dan gelembung waktu + judul bab saat digeser.
 */
@Composable
fun SeekBar(
    posMs: Long,
    durMs: Long,
    bufMs: Long,
    chapters: List<Chapter>,
    onSeek: (Long) -> Unit,
    onInteract: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var widthPx by remember { mutableIntStateOf(1) }
    var dragging by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableFloatStateOf(0f) }
    val live = if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f
    val frac = if (dragging) dragFrac else live
    val thick by animateFloatAsState(if (dragging) 8f else 4f, label = "thick")

    Box(
        modifier.fillMaxWidth().height(40.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            .pointerInput(durMs) {
                detectTapGestures { o ->
                    onSeek(((o.x / size.width).coerceIn(0f, 1f) * durMs).toLong())
                    onInteract()
                }
            }
            .pointerInput(durMs) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragging = true
                        dragFrac = (o.x / size.width).coerceIn(0f, 1f)
                        onInteract()
                    },
                    onDragEnd = {
                        onSeek((dragFrac * durMs).toLong())
                        dragging = false
                    },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, _ ->
                        dragFrac = (change.position.x / size.width).coerceIn(0f, 1f)
                        change.consume()
                        onInteract()
                    },
                )
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height / 2f
            val th = thick.dp.toPx()
            val top = Offset(0f, cy - th / 2f)
            val corner = CornerRadius(th / 2f)
            drawRoundRect(Color.White.copy(alpha = 0.22f), top, Size(size.width, th), corner)
            val b = if (durMs > 0) (bufMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f
            drawRoundRect(Color.White.copy(alpha = 0.34f), top, Size(size.width * b, th), corner)
            if (frac > 0f) {
                drawRoundRect(
                    brush = Brush.horizontalGradient(listOf(Violet, Cyan), 0f, size.width.coerceAtLeast(1f)),
                    topLeft = top,
                    size = Size(size.width * frac, th),
                    cornerRadius = corner,
                )
            }
            if (durMs > 0) {
                chapters.drop(1).forEach { c ->
                    val x = c.startSec * 1000f / durMs * size.width
                    drawRect(Color(0xFF0B0C12), Offset(x - 1.5.dp.toPx(), cy - th / 2f), Size(3.dp.toPx(), th))
                }
            }
            val r = (if (dragging) 9.dp else 6.dp).toPx()
            val x = size.width * frac
            drawCircle(Cyan.copy(alpha = 0.30f), r * 2f, Offset(x, cy))
            drawCircle(Color.White, r, Offset(x, cy))
        }
        if (dragging) {
            val sec = (dragFrac * durMs / 1000f).toLong()
            val ch = chapterAt(chapters, sec)
            Column(
                Modifier
                    .offset { IntOffset((dragFrac * widthPx - 60.dp.toPx()).coerceIn(0f, (widthPx - 120.dp.toPx()).coerceAtLeast(0f)).toInt(), -54.dp.roundToPx()) }
                    .width(120.dp)
                    .background(Color(0xE60F1017), RoundedCornerShape(14.dp))
                    .padding(vertical = 6.dp, horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(fmtDur(sec), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                if (ch != null) Text(ch.title, color = Cyan, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }
        }
    }
}
