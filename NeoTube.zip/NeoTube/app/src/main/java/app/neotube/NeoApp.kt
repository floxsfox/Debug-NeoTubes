package app.neotube

import android.app.Application
import app.neotube.data.NeoDownloader
import app.neotube.data.Playback
import app.neotube.data.ServiceLocator
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization

class NeoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
        Playback.init()
        NewPipe.init(NeoDownloader(ServiceLocator.okHttp), Localization("en", "US"), ContentCountry("ID"))
    }
}
