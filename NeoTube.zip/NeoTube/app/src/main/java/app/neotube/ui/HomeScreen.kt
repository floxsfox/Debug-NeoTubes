package app.neotube.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.neotube.data.Local
import app.neotube.data.Playback
import app.neotube.data.Repo
import app.neotube.data.SearchPage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory

object HomeState {
    var query by mutableStateOf("")
    var term by mutableStateOf("trending indonesia")
    var filter by mutableStateOf(YoutubeSearchQueryHandlerFactory.VIDEOS)
    var chip by mutableIntStateOf(0)
    var page by mutableStateOf(SearchPage())
    var key by mutableStateOf("")
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var reload by mutableIntStateOf(0)
    var focused by mutableStateOf(false)
    var suggestions by mutableStateOf<List<String>>(emptyList())
    val listState = LazyListState()
}

private val Cats = listOf(
    "Untuk Kamu" to "trending indonesia",
    "Musik" to "lagu terbaru",
    "Game" to "gameplay terbaru",
    "Film" to "trailer film terbaru",
    "Berita" to "berita terkini",
    "Teknologi" to "review gadget terbaru",
    "Olahraga" to "highlight olahraga",
    "Live" to "live streaming sekarang",
)

private val Filters = listOf(
    "Video" to YoutubeSearchQueryHandlerFactory.VIDEOS,
    "Kanal" to YoutubeSearchQueryHandlerFactory.CHANNELS,
    "Playlist" to YoutubeSearchQueryHandlerFactory.PLAYLISTS,
)

@Composable
fun HomeScreen() {
    val focus = LocalFocusManager.current
    val history by Local.searches.items.collectAsStateWithLifecycle()

    fun doSearch(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        focus.clearFocus()
        if (Repo.isVideoUrl(t)) {      // tempel tautan YouTube = langsung putar
            HomeState.query = ""
            Playback.open(t)
            return
        }
        Local.searches.push(t)
        HomeState.query = t
        HomeState.chip = -1
        HomeState.filter = YoutubeSearchQueryHandlerFactory.VIDEOS
        HomeState.term = t
    }

    LaunchedEffect(HomeState.term, HomeState.filter, HomeState.reload) {
        val k = HomeState.term + "|" + HomeState.filter
        if (k == HomeState.key && HomeState.error == null) return@LaunchedEffect
        HomeState.loading = true
        HomeState.error = null
        try {
            HomeState.page = Repo.search(HomeState.term, HomeState.filter)
            HomeState.key = k
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            HomeState.page = SearchPage()
            HomeState.error = e.message ?: e.toString()
        }
        HomeState.loading = false
    }

    LaunchedEffect(HomeState.query, HomeState.focused) {
        if (HomeState.focused && HomeState.query.isNotBlank()) {
            delay(250)
            HomeState.suggestions = try { Repo.suggestions(HomeState.query) } catch (e: CancellationException) { throw e } catch (e: Exception) { emptyList() }
        } else HomeState.suggestions = emptyList()
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        state = HomeState.listState,
        contentPadding = PaddingValues(top = topPad(), bottom = bottomPad()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            ScreenHeader("NeoTube") {
                GlassIconButton(Icons.Rounded.Settings, { Nav.push(Screen.Prefs) }, size = 42.dp)
            }
        }
        item {
            SearchField(
                value = HomeState.query,
                onChange = { HomeState.query = it },
                onSearch = { doSearch(HomeState.query) },
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }

        if (HomeState.focused) {
            if (HomeState.query.isBlank()) {
                items(history) { h ->
                    SuggestionRow(h, Icons.Rounded.History, onClick = { doSearch(h) }, onRemove = { Local.searches.remove(h) })
                }
            } else {
                items(HomeState.suggestions) { s ->
                    SuggestionRow(s, Icons.Rounded.TrendingUp, onClick = { doSearch(s) }, onRemove = null)
                }
            }
        } else {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
                    items(Cats.size) { i ->
                        GlassChip(Cats[i].first, selected = i == HomeState.chip, onClick = {
                            HomeState.chip = i
                            HomeState.query = ""
                            HomeState.filter = YoutubeSearchQueryHandlerFactory.VIDEOS
                            HomeState.term = Cats[i].second
                        })
                    }
                }
            }
            if (HomeState.chip == -1) {
                item {
                    Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Filters.forEach { (label, f) ->
                            GlassChip(label, selected = HomeState.filter == f, onClick = { HomeState.filter = f })
                        }
                    }
                }
            }
            if (HomeState.loading) {
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Cyan, strokeWidth = 3.dp)
                    }
                }
            }
            val err = HomeState.error
            if (err != null) {
                item {
                    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), onClick = { HomeState.key = ""; HomeState.reload++ }) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Gagal memuat", color = Color.White, fontWeight = FontWeight.Bold)
                            Text(err, color = TextDim, fontSize = 13.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
                            Text("Ketuk untuk coba lagi", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            items(HomeState.page.videos) { v ->
                VideoCard(v, onClick = { Playback.open(v.url) }, modifier = Modifier.padding(horizontal = 16.dp))
            }
            items(HomeState.page.channels) { c ->
                ChannelRow(c, onClick = { Nav.push(Screen.Channel(c.url)) }, modifier = Modifier.padding(horizontal = 16.dp))
            }
            items(HomeState.page.playlists) { p ->
                PlaylistRow(p, onClick = { Nav.push(Screen.Playlist(p.url)) }, modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, onSearch: () -> Unit, modifier: Modifier = Modifier) {
    GlassCard(modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, null, tint = Color.White.copy(alpha = 0.7f))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (value.isEmpty()) Text("Cari video, kanal, atau tempel tautan", color = Color.White.copy(alpha = 0.42f), fontSize = 16.sp, maxLines = 1)
                BasicTextField(
                    value = value,
                    onValueChange = onChange,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Cyan),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    modifier = Modifier.fillMaxWidth().onFocusChanged { HomeState.focused = it.isFocused },
                )
            }
            if (value.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Close, "Hapus", tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.clip(CircleShape).clickable { onChange("") }.padding(2.dp),
                )
            }
        }
    }
}

@Composable
private fun SuggestionRow(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, onRemove: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, tint = TextDim, modifier = Modifier.size(20.dp))
        Text(text, Modifier.weight(1f), color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (onRemove != null) {
            Icon(Icons.Rounded.Close, "Hapus", tint = TextDim, modifier = Modifier.size(20.dp).clickable { onRemove() })
        }
    }
}
