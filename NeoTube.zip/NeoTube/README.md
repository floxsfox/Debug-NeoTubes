# NeoTube 0.2.0

Klien YouTube alternatif untuk Android (Kotlin + Jetpack Compose, tema gelap liquid glass).
Mesin ekstraksi: NewPipeExtractor (versi di gradle.properties -> newpipeVersion). Tanpa akun Google;
langganan, riwayat, playlist disimpan lokal.

Build lewat GitHub Web:
1. Upload NeoTube.zip ke root repo (tanpa diekstrak).
2. Buat .github/workflows/build-neotube.yml (isi dari build-neotube.yml).
3. Actions -> Build NeoTube APK -> Run workflow.
4. Ambil APK di Artifacts -> NeoTube-Debug-APK.
