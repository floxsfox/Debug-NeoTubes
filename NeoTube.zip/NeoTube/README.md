# NeoTube

Klien YouTube alternatif untuk Android (Kotlin + Jetpack Compose, UI liquid glass).

- Mesin ekstraksi: NewPipeExtractor (versi diatur di `gradle.properties` -> `newpipeVersion`)
- Pemutar: Media3 ExoPlayer, video-only + audio-only digabung (jalur 1440p / 4K)
- Unduhan: Media3 DownloadManager -> cache di penyimpanan app, diputar offline dari Unduhan

## Build lewat GitHub Web
1. Upload `NeoTube.zip` ke root repo (tanpa diekstrak).
2. Buat file `.github/workflows/build-neotube.yml` (isi dari build-neotube.yml).
3. Tab Actions -> Build NeoTube APK -> Run workflow.
4. Ambil APK di Artifacts -> NeoTube-Debug-APK.
